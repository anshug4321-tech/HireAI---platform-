export function StepShell({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <div className="animate-fade-up">
      <h2 className="font-display text-xl font-bold text-ink md:text-2xl">{title}</h2>
      <p className="mt-1.5 text-sm text-mist">{description}</p>
      <div className="mt-7 grid gap-5">{children}</div>
    </div>
  );
}
