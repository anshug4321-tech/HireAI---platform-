"use client";

import { Check } from "lucide-react";
import { steps, StepId } from "@/types";
import { cn } from "@/lib/utils";

export function ProgressIndicator({
  currentId,
  completed,
  onStepClick,
}: {
  currentId: StepId;
  completed: Set<StepId>;
  onStepClick: (id: StepId) => void;
}) {
  const currentIndex = steps.findIndex((s) => s.id === currentId);

  return (
    <div>
      {/* desktop: full stepper */}
      <ol className="hidden items-center md:flex">
        {steps.map((step, i) => {
          const isCompleted = completed.has(step.id);
          const isCurrent = step.id === currentId;
          const isReachable = isCompleted || isCurrent || i <= currentIndex;

          return (
            <li key={step.id} className="flex flex-1 items-center last:flex-none">
              <button
                type="button"
                disabled={!isReachable}
                onClick={() => isReachable && onStepClick(step.id)}
                className="group flex flex-col items-center gap-2 disabled:cursor-not-allowed"
              >
                <span
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-full font-mono text-xs font-semibold transition-colors",
                    isCurrent && "bg-iris-gradient text-white shadow-glow",
                    !isCurrent && isCompleted && "bg-success-500 text-white",
                    !isCurrent && !isCompleted && "bg-black/[0.06] text-mist group-hover:bg-black/10"
                  )}
                >
                  {isCompleted && !isCurrent ? <Check size={15} /> : i + 1}
                </span>
                <span
                  className={cn(
                    "max-w-[6.5rem] text-center text-xs font-medium",
                    isCurrent ? "text-ink" : "text-mist"
                  )}
                >
                  {step.label}
                </span>
              </button>
              {i < steps.length - 1 && (
                <div className={cn("mx-2 h-px flex-1", isCompleted ? "bg-success-500" : "bg-black/10")} />
              )}
            </li>
          );
        })}
      </ol>

      {/* mobile: compact progress bar */}
      <div className="md:hidden">
        <div className="mb-2 flex items-center justify-between text-xs font-medium text-mist">
          <span>
            Step {currentIndex + 1} of {steps.length}
          </span>
          <span className="text-ink">{steps[currentIndex].label}</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-black/10">
          <div
            className="h-full rounded-full bg-iris-gradient transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
}
