"use client";

import { useState } from "react";
import { ArrowLeft, ArrowRight, CheckCircle2, Sparkles } from "lucide-react";
import { emptyRegistrationData, RegistrationData, StepId, steps } from "@/types";
import { FieldErrors, validateStep } from "@/lib/validation";
import { Button } from "@/components/ui/Button";
import { ProgressIndicator } from "@/components/registration/ProgressIndicator";
import { PersonalInfoStep } from "@/components/registration/steps/PersonalInfoStep";
import { EducationStep } from "@/components/registration/steps/EducationStep";
import { SkillsStep } from "@/components/registration/steps/SkillsStep";
import { ResumeUploadStep } from "@/components/registration/steps/ResumeUploadStep";
import { PortfolioStep } from "@/components/registration/steps/PortfolioStep";
import { LinkedInStep } from "@/components/registration/steps/LinkedInStep";
import { ReviewStep } from "@/components/registration/steps/ReviewStep";

export function RegistrationWizard() {
  const [data, setData] = useState<RegistrationData>(emptyRegistrationData);
  const [stepIndex, setStepIndex] = useState(0);
  const [completed, setCompleted] = useState<Set<StepId>>(new Set());
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const currentStep = steps[stepIndex];
  const isFirst = stepIndex === 0;
  const isReview = currentStep.id === "review";

  const goToStep = (id: StepId) => {
    const idx = steps.findIndex((s) => s.id === id);
    if (idx === -1) return;
    setErrors({});
    setStepIndex(idx);
  };

  const handleNext = () => {
    const stepErrors = validateStep(currentStep.id, data);
    if (Object.keys(stepErrors).length > 0) {
      setErrors(stepErrors);
      return;
    }
    setErrors({});
    setCompleted((prev) => new Set(prev).add(currentStep.id));
    if (stepIndex < steps.length - 1) setStepIndex(stepIndex + 1);
  };

  const handleBack = () => {
    setErrors({});
    if (stepIndex > 0) setStepIndex(stepIndex - 1);
  };

  const handleSubmit = () => {
    // UI preview — replace with a real submission call (e.g. multipart form data with the resume file).
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 1200);
  };

  if (submitted) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-6 text-center animate-fade-up">
        <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-iris-gradient shadow-glow">
          <CheckCircle2 size={28} className="text-white" />
        </div>
        <h1 className="font-display text-2xl font-bold text-ink">Application submitted</h1>
        <p className="mt-2 text-sm text-mist">
          Thanks, {data.personal.fullName.split(" ")[0] || "there"} — we&apos;ve received your application. You&apos;ll
          hear from us by email about next steps, including your interview.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-10 md:py-14">
      <div className="mb-8 flex items-center gap-2.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-iris-gradient text-sm font-bold text-white">
          H
        </span>
        <span className="font-display text-lg font-bold text-ink">HireAI</span>
        <span className="ml-1.5 flex items-center gap-1 rounded-full border border-iris-500/20 bg-iris-50 px-2.5 py-0.5 text-xs font-semibold text-iris-600">
          <Sparkles size={11} /> Candidate registration
        </span>
      </div>

      <div className="mb-10 rounded-2xl border border-black/[0.06] bg-white p-5 shadow-card md:p-6">
        <ProgressIndicator currentId={currentStep.id} completed={completed} onStepClick={goToStep} />
      </div>

      <div className="rounded-2xl border border-black/[0.06] bg-white p-6 shadow-card md:p-10">
        {currentStep.id === "personal" && (
          <PersonalInfoStep
            value={data.personal}
            onChange={(personal) => setData({ ...data, personal })}
            errors={errors}
          />
        )}
        {currentStep.id === "education" && (
          <EducationStep
            value={data.education}
            onChange={(education) => setData({ ...data, education })}
            errors={errors}
          />
        )}
        {currentStep.id === "skills" && (
          <SkillsStep
            value={data.skillsInfo}
            onChange={(skillsInfo) => setData({ ...data, skillsInfo })}
            errors={errors}
          />
        )}
        {currentStep.id === "resume" && (
          <ResumeUploadStep value={data.resume} onChange={(resume) => setData({ ...data, resume })} errors={errors} />
        )}
        {currentStep.id === "portfolio" && (
          <PortfolioStep
            value={data.portfolioUrl}
            onChange={(portfolioUrl) => setData({ ...data, portfolioUrl })}
            errors={errors}
          />
        )}
        {currentStep.id === "linkedin" && (
          <LinkedInStep
            value={data.linkedinUrl}
            onChange={(linkedinUrl) => setData({ ...data, linkedinUrl })}
            errors={errors}
          />
        )}
        {currentStep.id === "review" && <ReviewStep data={data} onEdit={goToStep} />}

        <div className="mt-9 flex items-center justify-between border-t border-black/[0.06] pt-6">
          <Button variant="ghost" size="md" onClick={handleBack} disabled={isFirst} className="!px-3">
            <ArrowLeft size={15} /> Back
          </Button>

          <div className="flex items-center gap-2">
            {currentStep.optional && !isReview && (
              <Button variant="secondary" onClick={() => { setCompleted((p) => new Set(p).add(currentStep.id)); setStepIndex(stepIndex + 1); }}>
                Skip
              </Button>
            )}
            {isReview ? (
              <Button onClick={handleSubmit} loading={submitting}>
                {submitting ? "Submitting…" : "Submit application"}
              </Button>
            ) : (
              <Button onClick={handleNext}>
                Continue <ArrowRight size={15} />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
