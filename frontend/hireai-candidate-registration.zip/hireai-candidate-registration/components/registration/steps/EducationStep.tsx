import { Education } from "@/types";
import { FieldErrors } from "@/lib/validation";
import { StepShell } from "@/components/registration/StepShell";
import { FieldWrapper, TextInput } from "@/components/ui/FormField";

export function EducationStep({
  value,
  onChange,
  errors,
}: {
  value: Education;
  onChange: (next: Education) => void;
  errors: FieldErrors;
}) {
  const set = (patch: Partial<Education>) => onChange({ ...value, ...patch });

  return (
    <StepShell title="Education" description="Tell us about your most recent or highest qualification.">
      <div className="grid gap-5 sm:grid-cols-2">
        <FieldWrapper label="Highest degree" htmlFor="degree" error={errors.degree}>
          <TextInput
            id="degree"
            placeholder="B.Tech, M.Sc, MBA…"
            value={value.degree}
            error={!!errors.degree}
            onChange={(e) => set({ degree: e.target.value })}
          />
        </FieldWrapper>
        <FieldWrapper label="Field of study" htmlFor="fieldOfStudy" error={errors.fieldOfStudy}>
          <TextInput
            id="fieldOfStudy"
            placeholder="Computer Science"
            value={value.fieldOfStudy}
            error={!!errors.fieldOfStudy}
            onChange={(e) => set({ fieldOfStudy: e.target.value })}
          />
        </FieldWrapper>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <FieldWrapper label="Institution" htmlFor="institution" error={errors.institution}>
          <TextInput
            id="institution"
            placeholder="University name"
            value={value.institution}
            error={!!errors.institution}
            onChange={(e) => set({ institution: e.target.value })}
          />
        </FieldWrapper>
        <FieldWrapper label="Graduation year" htmlFor="graduationYear" error={errors.graduationYear}>
          <TextInput
            id="graduationYear"
            inputMode="numeric"
            placeholder="2024"
            value={value.graduationYear}
            error={!!errors.graduationYear}
            onChange={(e) => set({ graduationYear: e.target.value })}
          />
        </FieldWrapper>
      </div>
    </StepShell>
  );
}
