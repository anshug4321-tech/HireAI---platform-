import { Linkedin } from "lucide-react";
import { FieldErrors } from "@/lib/validation";
import { StepShell } from "@/components/registration/StepShell";
import { FieldWrapper, TextInput } from "@/components/ui/FormField";

export function LinkedInStep({
  value,
  onChange,
  errors,
}: {
  value: string;
  onChange: (next: string) => void;
  errors: FieldErrors;
}) {
  return (
    <StepShell title="LinkedIn profile" description="Add your LinkedIn so we can see your full professional background.">
      <FieldWrapper label="LinkedIn URL" htmlFor="linkedinUrl" error={errors.linkedinUrl} optional>
        <div className="relative">
          <Linkedin size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
          <TextInput
            id="linkedinUrl"
            type="url"
            placeholder="https://linkedin.com/in/your-name"
            value={value}
            error={!!errors.linkedinUrl}
            onChange={(e) => onChange(e.target.value)}
            className="pl-10"
          />
        </div>
      </FieldWrapper>
    </StepShell>
  );
}
