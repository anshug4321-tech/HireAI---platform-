import { ExperienceLevel, SkillsInfo } from "@/types";
import { FieldErrors } from "@/lib/validation";
import { StepShell } from "@/components/registration/StepShell";
import { FieldWrapper, Select, TextInput } from "@/components/ui/FormField";
import { TagInput } from "@/components/ui/TagInput";

const levels: ExperienceLevel[] = ["Entry-level", "Mid-level", "Senior", "Lead / Principal"];

export function SkillsStep({
  value,
  onChange,
  errors,
}: {
  value: SkillsInfo;
  onChange: (next: SkillsInfo) => void;
  errors: FieldErrors;
}) {
  const set = (patch: Partial<SkillsInfo>) => onChange({ ...value, ...patch });

  return (
    <StepShell title="Skills & experience" description="Add the skills most relevant to the role you're applying for.">
      <FieldWrapper label="Skills" htmlFor="skills" error={errors.skills} hint="Press Enter or comma after each skill.">
        <TagInput value={value.skills} onChange={(skills) => set({ skills })} error={!!errors.skills} />
      </FieldWrapper>

      <div className="grid gap-5 sm:grid-cols-2">
        <FieldWrapper label="Experience level" htmlFor="experienceLevel" error={errors.experienceLevel}>
          <Select
            id="experienceLevel"
            value={value.experienceLevel}
            error={!!errors.experienceLevel}
            onChange={(e) => set({ experienceLevel: e.target.value as ExperienceLevel })}
          >
            <option value="" disabled>
              Select a level
            </option>
            {levels.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </Select>
        </FieldWrapper>
        <FieldWrapper label="Years of experience" htmlFor="yearsOfExperience" error={errors.yearsOfExperience}>
          <TextInput
            id="yearsOfExperience"
            inputMode="decimal"
            placeholder="e.g. 3"
            value={value.yearsOfExperience}
            error={!!errors.yearsOfExperience}
            onChange={(e) => set({ yearsOfExperience: e.target.value })}
          />
        </FieldWrapper>
      </div>
    </StepShell>
  );
}
