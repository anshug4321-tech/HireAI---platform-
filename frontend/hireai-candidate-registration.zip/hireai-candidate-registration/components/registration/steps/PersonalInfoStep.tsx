import { PersonalInfo } from "@/types";
import { FieldErrors } from "@/lib/validation";
import { StepShell } from "@/components/registration/StepShell";
import { FieldWrapper, TextInput } from "@/components/ui/FormField";

export function PersonalInfoStep({
  value,
  onChange,
  errors,
}: {
  value: PersonalInfo;
  onChange: (next: PersonalInfo) => void;
  errors: FieldErrors;
}) {
  const set = (patch: Partial<PersonalInfo>) => onChange({ ...value, ...patch });

  return (
    <StepShell title="Personal information" description="Let's start with the basics — how we'll reach you.">
      <div className="grid gap-5 sm:grid-cols-2">
        <FieldWrapper label="Full name" htmlFor="fullName" error={errors.fullName}>
          <TextInput
            id="fullName"
            placeholder="Jordan Lee"
            value={value.fullName}
            error={!!errors.fullName}
            onChange={(e) => set({ fullName: e.target.value })}
          />
        </FieldWrapper>
        <FieldWrapper label="Current location" htmlFor="location" error={errors.location}>
          <TextInput
            id="location"
            placeholder="San Francisco, CA"
            value={value.location}
            error={!!errors.location}
            onChange={(e) => set({ location: e.target.value })}
          />
        </FieldWrapper>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <FieldWrapper label="Email address" htmlFor="email" error={errors.email}>
          <TextInput
            id="email"
            type="email"
            placeholder="jordan@example.com"
            value={value.email}
            error={!!errors.email}
            onChange={(e) => set({ email: e.target.value })}
          />
        </FieldWrapper>
        <FieldWrapper label="Mobile number" htmlFor="phone" error={errors.phone}>
          <TextInput
            id="phone"
            type="tel"
            placeholder="+1 555 000 0000"
            value={value.phone}
            error={!!errors.phone}
            onChange={(e) => set({ phone: e.target.value })}
          />
        </FieldWrapper>
      </div>
    </StepShell>
  );
}
