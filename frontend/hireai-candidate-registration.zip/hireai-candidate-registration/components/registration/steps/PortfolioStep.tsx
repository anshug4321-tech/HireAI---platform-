import { Globe } from "lucide-react";
import { FieldErrors } from "@/lib/validation";
import { StepShell } from "@/components/registration/StepShell";
import { FieldWrapper, TextInput } from "@/components/ui/FormField";

export function PortfolioStep({
  value,
  onChange,
  errors,
}: {
  value: string;
  onChange: (next: string) => void;
  errors: FieldErrors;
}) {
  return (
    <StepShell title="Portfolio link" description="Share a link to your work, if you have one — case studies, GitHub, a personal site.">
      <FieldWrapper label="Portfolio URL" htmlFor="portfolioUrl" error={errors.portfolioUrl} optional>
        <div className="relative">
          <Globe size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mist" />
          <TextInput
            id="portfolioUrl"
            type="url"
            placeholder="https://your-portfolio.com"
            value={value}
            error={!!errors.portfolioUrl}
            onChange={(e) => onChange(e.target.value)}
            className="pl-10"
          />
        </div>
      </FieldWrapper>
    </StepShell>
  );
}
