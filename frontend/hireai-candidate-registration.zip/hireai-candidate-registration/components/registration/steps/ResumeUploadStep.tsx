import { ResumeInfo } from "@/types";
import { FieldErrors } from "@/lib/validation";
import { StepShell } from "@/components/registration/StepShell";
import { FileDropzone } from "@/components/ui/FileDropzone";
import { Alert } from "@/components/ui/Alert";

export function ResumeUploadStep({
  value,
  onChange,
  errors,
}: {
  value: ResumeInfo;
  onChange: (next: ResumeInfo) => void;
  errors: FieldErrors;
}) {
  return (
    <StepShell title="Upload your resume" description="We'll use this alongside your interview to evaluate your fit.">
      <FileDropzone value={value} onChange={onChange} error={errors.file} />
      <Alert tone="info">
        This is a UI preview — your file stays in the browser and isn&apos;t uploaded anywhere yet.
      </Alert>
    </StepShell>
  );
}
