import { Pencil } from "lucide-react";
import { RegistrationData, StepId } from "@/types";
import { formatFileSize } from "@/lib/utils";
import { StepShell } from "@/components/registration/StepShell";

function ReviewSection({
  title,
  onEdit,
  children,
}: {
  title: string;
  onEdit: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-black/10 bg-white p-5">
      <div className="mb-3 flex items-center justify-between">
        <p className="font-display text-sm font-semibold text-ink">{title}</p>
        <button
          type="button"
          onClick={onEdit}
          className="flex items-center gap-1 text-xs font-medium text-iris-600 hover:text-iris-500"
        >
          <Pencil size={12} /> Edit
        </button>
      </div>
      <div className="grid gap-1.5 text-sm text-mist">{children}</div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-mist/70">{label}</span>
      <span className="text-right font-medium text-ink">{value || "—"}</span>
    </div>
  );
}

export function ReviewStep({ data, onEdit }: { data: RegistrationData; onEdit: (id: StepId) => void }) {
  return (
    <StepShell title="Review & submit" description="Make sure everything looks right before you submit your application.">
      <ReviewSection title="Personal information" onEdit={() => onEdit("personal")}>
        <Row label="Full name" value={data.personal.fullName} />
        <Row label="Email" value={data.personal.email} />
        <Row label="Phone" value={data.personal.phone} />
        <Row label="Location" value={data.personal.location} />
      </ReviewSection>

      <ReviewSection title="Education" onEdit={() => onEdit("education")}>
        <Row label="Degree" value={data.education.degree} />
        <Row label="Field of study" value={data.education.fieldOfStudy} />
        <Row label="Institution" value={data.education.institution} />
        <Row label="Graduation year" value={data.education.graduationYear} />
      </ReviewSection>

      <ReviewSection title="Skills & experience" onEdit={() => onEdit("skills")}>
        <Row label="Experience level" value={data.skillsInfo.experienceLevel} />
        <Row label="Years of experience" value={data.skillsInfo.yearsOfExperience} />
        <div className="mt-1 flex flex-wrap gap-1.5">
          {data.skillsInfo.skills.length ? (
            data.skillsInfo.skills.map((s) => (
              <span key={s} className="rounded-full bg-iris-gradient-soft px-2.5 py-1 text-xs font-medium text-iris-600">
                {s}
              </span>
            ))
          ) : (
            <span className="text-sm text-mist/70">No skills added</span>
          )}
        </div>
      </ReviewSection>

      <ReviewSection title="Resume" onEdit={() => onEdit("resume")}>
        <Row
          label="File"
          value={data.resume.fileName ? `${data.resume.fileName} (${formatFileSize(data.resume.fileSize)})` : ""}
        />
      </ReviewSection>

      <ReviewSection title="Links" onEdit={() => onEdit("portfolio")}>
        <Row label="Portfolio" value={data.portfolioUrl} />
        <Row label="LinkedIn" value={data.linkedinUrl} />
      </ReviewSection>
    </StepShell>
  );
}
