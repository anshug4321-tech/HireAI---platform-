"use client";

import { KeyboardEvent, useState } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export function TagInput({
  value,
  onChange,
  placeholder = "Type a skill and press Enter",
  error,
}: {
  value: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  error?: boolean;
}) {
  const [draft, setDraft] = useState("");

  const addTag = (raw: string) => {
    const tag = raw.trim().replace(/,$/, "");
    if (!tag) return;
    if (value.some((t) => t.toLowerCase() === tag.toLowerCase())) {
      setDraft("");
      return;
    }
    onChange([...value, tag]);
    setDraft("");
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(draft);
    } else if (e.key === "Backspace" && draft === "" && value.length > 0) {
      onChange(value.slice(0, -1));
    }
  };

  return (
    <div
      className={cn(
        "flex min-h-[3rem] flex-wrap items-center gap-2 rounded-lg border border-black/12 bg-white px-3 py-2.5 focus-within:border-iris-400",
        error && "!border-danger-500"
      )}
    >
      {value.map((tag) => (
        <span
          key={tag}
          className="flex items-center gap-1.5 rounded-full bg-iris-gradient-soft px-3 py-1 text-xs font-medium text-iris-600"
        >
          {tag}
          <button
            type="button"
            onClick={() => onChange(value.filter((t) => t !== tag))}
            className="text-iris-600/70 hover:text-iris-600"
            aria-label={`Remove ${tag}`}
          >
            <X size={12} />
          </button>
        </span>
      ))}
      <input
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => addTag(draft)}
        placeholder={value.length === 0 ? placeholder : "Add another…"}
        className="min-w-[8rem] flex-1 border-none bg-transparent text-sm outline-none placeholder:text-mist/60"
      />
    </div>
  );
}
