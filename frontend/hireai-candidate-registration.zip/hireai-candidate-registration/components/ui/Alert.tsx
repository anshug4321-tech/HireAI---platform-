import { AlertTriangle, CheckCircle2, Info } from "lucide-react";
import { cn } from "@/lib/utils";

type Tone = "error" | "success" | "info";

const styles: Record<Tone, { wrap: string; icon: React.ElementType }> = {
  error: { wrap: "border-danger-500/25 bg-danger-50 text-[#8a3527]", icon: AlertTriangle },
  success: { wrap: "border-success-500/25 bg-success-50 text-[#255d45]", icon: CheckCircle2 },
  info: { wrap: "border-iris-500/20 bg-iris-50 text-iris-600", icon: Info },
};

export function Alert({ tone = "info", children }: { tone?: Tone; children: React.ReactNode }) {
  const { wrap, icon: Icon } = styles[tone];
  return (
    <div className={cn("flex items-start gap-2.5 rounded-lg border px-3.5 py-3 text-sm", wrap)}>
      <Icon size={16} className="mt-0.5 shrink-0" />
      <div>{children}</div>
    </div>
  );
}
