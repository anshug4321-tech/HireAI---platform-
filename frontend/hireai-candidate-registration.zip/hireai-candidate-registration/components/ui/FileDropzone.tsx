"use client";

import { DragEvent, useRef, useState } from "react";
import { FileText, UploadCloud, X } from "lucide-react";
import { formatFileSize, cn } from "@/lib/utils";
import { ResumeInfo } from "@/types";

const ACCEPTED = [".pdf", ".doc", ".docx"];
const MAX_SIZE_MB = 5;

export function FileDropzone({
  value,
  onChange,
  error,
}: {
  value: ResumeInfo;
  onChange: (next: ResumeInfo) => void;
  error?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [localError, setLocalError] = useState("");

  const applyFile = (file: File | undefined) => {
    if (!file) return;
    const ext = "." + file.name.split(".").pop()?.toLowerCase();
    if (!ACCEPTED.includes(ext)) {
      setLocalError("Unsupported format. Upload a PDF, DOC, or DOCX file.");
      return;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setLocalError(`File is too large. Max size is ${MAX_SIZE_MB}MB.`);
      return;
    }
    setLocalError("");
    // UI preview — the file stays in memory only, nothing is uploaded anywhere yet.
    onChange({ file, fileName: file.name, fileSize: file.size });
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragging(false);
    applyFile(e.dataTransfer.files?.[0]);
  };

  if (value.file) {
    return (
      <div className="flex items-center justify-between rounded-xl border border-black/10 bg-white p-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-iris-gradient-soft text-iris-600">
            <FileText size={18} />
          </span>
          <div>
            <p className="text-sm font-medium text-ink">{value.fileName}</p>
            <p className="text-xs text-mist">{formatFileSize(value.fileSize)} · uploaded</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => onChange({ file: null, fileName: "", fileSize: 0 })}
          className="flex h-8 w-8 items-center justify-center rounded-lg text-mist hover:bg-danger-50 hover:text-danger-500"
          aria-label="Remove resume"
        >
          <X size={16} />
        </button>
      </div>
    );
  }

  return (
    <div>
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && inputRef.current?.click()}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors",
          dragging ? "border-iris-400 bg-iris-50" : "border-black/15 bg-white hover:border-iris-400/50",
          (error || localError) && "border-danger-500"
        )}
      >
        <span className="flex h-11 w-11 items-center justify-center rounded-full bg-iris-gradient-soft text-iris-600">
          <UploadCloud size={20} />
        </span>
        <p className="text-sm font-medium text-ink">
          <span className="text-iris-600">Click to upload</span> or drag and drop
        </p>
        <p className="text-xs text-mist">PDF, DOC, or DOCX · up to {MAX_SIZE_MB}MB</p>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED.join(",")}
          className="hidden"
          onChange={(e) => applyFile(e.target.files?.[0])}
        />
      </div>
      {(error || localError) && (
        <p className="mt-1.5 text-xs font-medium text-danger-500">{error || localError}</p>
      )}
    </div>
  );
}
