import { forwardRef, InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export function FieldWrapper({
  label,
  htmlFor,
  error,
  hint,
  optional,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  optional?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="grid gap-1.5">
      <div className="flex items-center justify-between">
        <label htmlFor={htmlFor} className="font-mono text-xs uppercase tracking-wide text-mist">
          {label}
        </label>
        {optional && <span className="text-xs text-mist/70">Optional</span>}
      </div>
      {children}
      {error ? (
        <p className="flex items-center gap-1.5 text-xs font-medium text-danger-500">
          <AlertCircle size={12} /> {error}
        </p>
      ) : (
        hint && <p className="text-xs text-mist/80">{hint}</p>
      )}
    </div>
  );
}

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
}

export const TextInput = forwardRef<HTMLInputElement, InputProps>(function TextInput(
  { error, className, ...props },
  ref
) {
  return <input ref={ref} className={cn("field", error && "!border-danger-500", className)} {...props} />;
});

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { error, className, ...props },
  ref
) {
  return (
    <textarea ref={ref} className={cn("field resize-none", error && "!border-danger-500", className)} {...props} />
  );
});

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  error?: boolean;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select(
  { error, className, children, ...props },
  ref
) {
  return (
    <select ref={ref} className={cn("field appearance-none bg-white", error && "!border-danger-500", className)} {...props}>
      {children}
    </select>
  );
});
