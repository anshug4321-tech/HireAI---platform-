# HireAI — Candidate Registration Module

A multi-step candidate registration wizard for HireAI, built with Next.js (App Router), React,
TypeScript, and Tailwind CSS. **UI only** — validation is real and runs entirely in the browser, but
nothing is submitted to a server. The resume file is read into memory for preview only.

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000 — it redirects to `/register`.

## Steps

1. **Personal Information** — full name, email, mobile number, location
2. **Education** — highest degree, field of study, institution, graduation year
3. **Skills** — tag-based skill input, experience level, years of experience
4. **Resume Upload** *(UI only)* — drag-and-drop or click-to-browse, PDF/DOC/DOCX up to 5MB, file stays
   in memory, never uploaded
5. **Portfolio URL** *(optional)* — validated as a well-formed URL if filled in
6. **LinkedIn URL** *(optional)* — validated as a well-formed `linkedin.com` URL if filled in
7. **Review & Submit** — read-only summary of every step with "Edit" links back to each one, then a
   mocked submit that shows a confirmation screen

## Structure

```
app/
  layout.tsx                       Fonts + metadata
  page.tsx                         Redirects to /register
  register/page.tsx                Mounts the wizard

components/
  registration/
    RegistrationWizard.tsx          Owns step state, form data, validation, and navigation
    ProgressIndicator.tsx           Full stepper (desktop) / progress bar (mobile), click-to-jump
    StepShell.tsx                   Shared title + description wrapper for every step
    steps/
      PersonalInfoStep.tsx
      EducationStep.tsx
      SkillsStep.tsx
      ResumeUploadStep.tsx
      PortfolioStep.tsx
      LinkedInStep.tsx
      ReviewStep.tsx                Section-by-section summary with per-section "Edit"
  ui/
    Button.tsx                      Primary/secondary/ghost, built-in loading state
    FormField.tsx                   FieldWrapper (label/error/hint) + TextInput/Textarea/Select
    TagInput.tsx                    Chip-style skill entry (Enter/comma to add, backspace to remove)
    FileDropzone.tsx                Drag-and-drop resume upload with type/size validation
    Alert.tsx                       Inline info/success/error banner

lib/
  utils.ts                          cn() classname helper, formatFileSize()
  validation.ts                     Per-step and per-field validators, dispatched by validateStep()

types/
  index.ts                          RegistrationData, per-section types, step config (steps[])
```

## How the wizard works

- All form state lives in one `RegistrationData` object in `RegistrationWizard`, updated section-by-section
  as each step component calls its `onChange`.
- Step order and labels are driven by a single `steps` config array in `types/index.ts` — the stepper,
  navigation, and routing all read from it, so reordering or adding a step means editing one array.
- `validateStep(id, data)` runs the right validator for whichever step you're leaving; errors block
  "Continue" and surface inline under each field.
- Completed steps are tracked in a `Set`, which drives both the checkmarks in the stepper and which steps
  are click-to-jump reachable (you can revisit anything already completed or the current step, not skip
  ahead blindly).
- Portfolio and LinkedIn are marked optional in the step config — a "Skip" button appears for them, and
  their validators only check format, not presence.

## What's mocked

- Final submission (`handleSubmit` in `RegistrationWizard.tsx`) — simulates a delay, then shows a success
  screen. Marked `UI preview` in the code.
- Resume upload — file is validated (type, size) and held in component state via the browser's `File` API;
  it is never sent anywhere.

## Design system

Matches the rest of the HireAI product: ink `#12131C`, cloud `#F5F6FE`, iris blue `#4A5FFF` → violet
`#8B5CF6` gradient, Sora display type, Inter body, JetBrains Mono for small labels and step numbers.

## Next steps (not built here)

- Real submission endpoint (likely multipart form data for the resume file)
- Resume parsing / auto-fill of skills and education from the uploaded file
- Duplicate-application detection by email
- Persisting partial progress (e.g. so a refresh doesn't lose the form)
