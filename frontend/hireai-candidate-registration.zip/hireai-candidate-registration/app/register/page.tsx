import { RegistrationWizard } from "@/components/registration/RegistrationWizard";

export default function RegisterPage() {
  return (
    <main className="min-h-screen bg-cloud">
      <RegistrationWizard />
    </main>
  );
}
