export interface PersonalInfo {
  fullName: string;
  email: string;
  phone: string;
  location: string;
}

export interface Education {
  degree: string;
  institution: string;
  fieldOfStudy: string;
  graduationYear: string;
}

export interface SkillsInfo {
  skills: string[];
  experienceLevel: ExperienceLevel | "";
  yearsOfExperience: string;
}

export type ExperienceLevel = "Entry-level" | "Mid-level" | "Senior" | "Lead / Principal";

export interface ResumeInfo {
  file: File | null;
  fileName: string;
  fileSize: number;
}

export interface RegistrationData {
  personal: PersonalInfo;
  education: Education;
  skillsInfo: SkillsInfo;
  resume: ResumeInfo;
  portfolioUrl: string;
  linkedinUrl: string;
}

export const emptyRegistrationData: RegistrationData = {
  personal: { fullName: "", email: "", phone: "", location: "" },
  education: { degree: "", institution: "", fieldOfStudy: "", graduationYear: "" },
  skillsInfo: { skills: [], experienceLevel: "", yearsOfExperience: "" },
  resume: { file: null, fileName: "", fileSize: 0 },
  portfolioUrl: "",
  linkedinUrl: "",
};

export type StepId =
  | "personal"
  | "education"
  | "skills"
  | "resume"
  | "portfolio"
  | "linkedin"
  | "review";

export interface StepMeta {
  id: StepId;
  label: string;
  optional?: boolean;
}

export const steps: StepMeta[] = [
  { id: "personal", label: "Personal Info" },
  { id: "education", label: "Education" },
  { id: "skills", label: "Skills" },
  { id: "resume", label: "Resume" },
  { id: "portfolio", label: "Portfolio", optional: true },
  { id: "linkedin", label: "LinkedIn", optional: true },
  { id: "review", label: "Review & Submit" },
];
