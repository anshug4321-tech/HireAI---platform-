import { Education, PersonalInfo, RegistrationData, ResumeInfo, SkillsInfo, StepId } from "@/types";

export function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export function isValidPhone(value: string) {
  return /^[+]?[\d\s()-]{7,20}$/.test(value.trim());
}

export function isValidUrl(value: string) {
  if (!value.trim()) return true; // optional fields validate format only when filled
  try {
    const url = new URL(value.trim());
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export function isValidLinkedInUrl(value: string) {
  if (!value.trim()) return true;
  return isValidUrl(value) && /linkedin\.com/i.test(value);
}

export type FieldErrors = Record<string, string>;

export function validatePersonal(v: PersonalInfo): FieldErrors {
  const e: FieldErrors = {};
  if (!v.fullName.trim()) e.fullName = "Enter your full name.";
  if (!v.email.trim()) e.email = "Enter your email address.";
  else if (!isValidEmail(v.email)) e.email = "Enter a valid email address.";
  if (!v.phone.trim()) e.phone = "Enter your mobile number.";
  else if (!isValidPhone(v.phone)) e.phone = "Enter a valid phone number.";
  if (!v.location.trim()) e.location = "Enter your current location.";
  return e;
}

export function validateEducation(v: Education): FieldErrors {
  const e: FieldErrors = {};
  if (!v.degree.trim()) e.degree = "Enter your highest degree.";
  if (!v.institution.trim()) e.institution = "Enter your institution name.";
  if (!v.fieldOfStudy.trim()) e.fieldOfStudy = "Enter your field of study.";
  if (!v.graduationYear.trim()) e.graduationYear = "Enter your graduation year.";
  else if (!/^\d{4}$/.test(v.graduationYear.trim())) e.graduationYear = "Enter a 4-digit year.";
  return e;
}

export function validateSkills(v: SkillsInfo): FieldErrors {
  const e: FieldErrors = {};
  if (v.skills.length === 0) e.skills = "Add at least one skill.";
  if (!v.experienceLevel) e.experienceLevel = "Select your experience level.";
  if (!v.yearsOfExperience.trim()) e.yearsOfExperience = "Enter your years of experience.";
  else if (Number.isNaN(Number(v.yearsOfExperience))) e.yearsOfExperience = "Enter a number.";
  return e;
}

export function validateResume(v: ResumeInfo): FieldErrors {
  const e: FieldErrors = {};
  if (!v.file) e.file = "Upload your resume to continue.";
  return e;
}

export function validatePortfolio(url: string): FieldErrors {
  const e: FieldErrors = {};
  if (!isValidUrl(url)) e.portfolioUrl = "Enter a valid URL (starting with https://).";
  return e;
}

export function validateLinkedin(url: string): FieldErrors {
  const e: FieldErrors = {};
  if (url.trim() && !isValidUrl(url)) e.linkedinUrl = "Enter a valid URL (starting with https://).";
  else if (url.trim() && !isValidLinkedInUrl(url)) e.linkedinUrl = "Enter a linkedin.com profile URL.";
  return e;
}

export function validateStep(id: StepId, data: RegistrationData): FieldErrors {
  switch (id) {
    case "personal":
      return validatePersonal(data.personal);
    case "education":
      return validateEducation(data.education);
    case "skills":
      return validateSkills(data.skillsInfo);
    case "resume":
      return validateResume(data.resume);
    case "portfolio":
      return validatePortfolio(data.portfolioUrl);
    case "linkedin":
      return validateLinkedin(data.linkedinUrl);
    default:
      return {};
  }
}
