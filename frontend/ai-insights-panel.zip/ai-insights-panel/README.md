# AIInsightsPanel

A production-ready AI recruiter insights panel for the HireAI dashboard. Drop the `components/`
folder into your Next.js project (paths assume the `@/` alias already points at your project root,
same convention as the rest of HireAI).

## Install

```bash
npm install framer-motion lucide-react clsx
```

## Usage

```tsx
import { AIInsightsPanel } from "@/components/AIInsightsPanel";
// or: import { AIInsightsPanel } from "@/components"; (barrel export)

export default function DashboardPage() {
  return (
    <AIInsightsPanel
      insights={insights}          // optional — defaults to bundled mock data
      isLoading={isLoadingInsights} // optional — defaults to false
      onInsightAction={(insight) => router.push(`/dashboard/insights/${insight.id}`)}
    />
  );
}
```

With zero props it renders fully populated with realistic mock data — useful for storybook-style
preview or while the real endpoint is still being built.

## Files

```
types/insight.ts                 AIInsight, InsightCategory, InsightPriority, badge meta types
data/mock-insights.ts             8 realistic mock insights (recommendation/alert/forecast/suggestion/performance)
lib/utils.ts                      cn(), formatRelativeTime(), clampConfidence() — pure, unit-testable
components/
  AIInsightsPanel.tsx              Default export. Owns search/filter state, composes everything below.
  InsightCard.tsx                  One insight — icon, title, confidence ring, badges, CTA
  ConfidenceCircle.tsx             Animated circular progress — the panel's signature element
  PriorityBadge.tsx                High/Medium/Low pill (red/amber/emerald)
  CategoryBadge.tsx                Category pill + CATEGORY_META lookup (icon/label/color per category)
  InsightCardSkeleton.tsx          Skeleton card + InsightCardSkeletonGrid loading state
  EmptyState.tsx                   EmptyState ("no data") + NoMatchesState ("no search results")
  index.ts                         Barrel export
```

## Required Tailwind tokens

This component reuses the same design tokens as the rest of HireAI (ink / cloud / mist / iris /
violet / success / danger, plus `abyss.*` for dark-mode surfaces). If you're pasting this into the
same codebase as the dashboard sidebar module, you already have all of these. If not, add to
`tailwind.config.ts`:

```ts
darkMode: "class",
theme: {
  extend: {
    colors: {
      ink: "#12131C",
      mist: "#5B6172",
      cloud: "#F5F6FE",
      success: { 50: "#EAF7F1", 500: "#3D9670" },
      danger: { 50: "#FBEAE7", 500: "#D1543F" },
      iris: { 50: "#EEF1FF", 100: "#DFE4FF", 400: "#6C7CFF", 500: "#4A5FFF", 600: "#3646E0" },
      violet: { 400: "#A78BFA", 500: "#8B5CF6", 600: "#7C3AED" },
      abyss: { DEFAULT: "#0B0C14", surface: "#14151F", raised: "#1B1C29", border: "#FFFFFF14" },
    },
    backgroundImage: {
      "iris-gradient": "linear-gradient(135deg, #4A5FFF 0%, #8B5CF6 100%)",
      "iris-gradient-soft": "linear-gradient(135deg, #EEF1FF 0%, #F3EEFF 100%)",
    },
    boxShadow: {
      glow: "0 20px 60px -15px rgba(90,92,255,0.35)",
      card: "0 1px 2px rgba(18,19,28,0.04), 0 12px 28px -12px rgba(18,19,28,0.08)",
    },
  },
},
```

`amber-*` (used for Medium priority) is a Tailwind default and needs no extra config. Fonts
(`font-display`/`font-mono`) fall back gracefully to `sans-serif`/`monospace` if you haven't wired up
Sora/JetBrains Mono — nothing breaks, it just won't match the exact type system.

## How each requirement is met

- **Search** — real-time, filters on title + description + category. Runs through
  `useDeferredValue` so typing stays responsive regardless of list size.
- **Filter** — native `<select>` (full keyboard support for free, no custom-combobox a11y bugs to get
  wrong), options driven by `INSIGHT_CATEGORIES` so adding a category is a one-line change.
- **Confidence score** — `ConfidenceCircle` tweens a single value with `framer-motion`'s `animate()`
  that drives *both* the ring sweep and the counted-up number, so they can never drift apart. Ring
  color scales with score (≥90 green, ≥80 iris, below amber).
- **Loading state** — `InsightCardSkeletonGrid`, laid out identically to the real card grid so there's
  no layout jump when data arrives. Controlled entirely by the `isLoading` prop — nothing is faked
  with an internal timer, since real loading state should come from your data fetching.
- **Empty state** — exact copy requested ("No AI Insights Available" / "Insights will appear after AI
  analyzes candidate data"), separate from `NoMatchesState`, which is what shows when insights exist
  but the current search/filter matches none — different message, different recovery action (a
  "Clear search & filters" button), because "you have zero data" and "you filtered too narrowly" are
  different problems with different fixes.
- **Animation** — fade+slide-up entrance staggered by index, hover lift on cards, hover/tap scale on
  the CTA button, and the confidence ring/counter tween. Every animated value is gated by
  `useReducedMotion()` and drops to instant with zero duration when the user has
  `prefers-reduced-motion: reduce` set — this is a real branch in the code, not just a CSS override.
- **Responsive** — 1 column on mobile, 2 from `sm:`, 3 from `xl:`. Header stacks search/filter above
  the title on narrow screens, sits inline on `md:` and up.
- **Accessibility** — see below.
- **Dark mode** — every surface, border, and text color has a `dark:` variant; assumes `darkMode:
  "class"` in your Tailwind config (same as the sidebar module).
- **TypeScript** — no `any` anywhere; `InsightCategory`/`InsightPriority` are unions (not raw
  strings), so `Record<InsightCategory, …>` lookups are exhaustively checked by the compiler if a
  category is ever added or removed.
- **Performance** — `AIInsightsPanel`, `InsightCard`, `ConfidenceCircle`, `PriorityBadge`, and
  `CategoryBadge` are all wrapped in `React.memo`; filtering is `useMemo`'d off a deferred search
  value; the action handler is `useCallback`'d so `InsightCard` doesn't re-render on every keystroke.
- **Clean architecture** — one component, one job, in its own file: `InsightCard`,
  `ConfidenceCircle`, `PriorityBadge`, `CategoryBadge`, `InsightCardSkeleton`, `EmptyState` are all
  separately exported and independently reusable/testable.

## Accessibility specifics

- Collapsed or not, every badge/card/button keeps a real accessible name — priority and category
  badges use `aria-label` (full phrase) over abbreviated visible text; the confidence ring is
  `role="img"` with `aria-label="AI confidence score: 96%"`; decorative icons are all `aria-hidden`.
- Each card is `<article aria-labelledby={titleId}>` so screen readers announce the insight title
  before its content, and the CTA button has its own `aria-label` combining the action with the
  insight title (`"Schedule interview: Schedule an interview with John Doe"`) so it's unambiguous
  when read out of visual context.
- A polite `aria-live` region announces result counts as you search/filter, without interrupting
  mid-keystroke.
- The CTA button has an explicit `focus-visible` ring in its own class list (not just relying on a
  global stylesheet), so focus is visible even if this component is dropped into a project that
  hasn't set up global `:focus-visible` styling yet.
- Search input and category filter are real `<input>`/`<select>` elements with associated `<label>`s
  (visually hidden via `sr-only`, not `aria-label`-only) — full native keyboard support, no custom
  widget re-implementation.

## Notes on the mock data / no-backend boundary

`onInsightAction` is the only integration point this component needs from a real backend — everything
else (search, filter, animation, loading/empty states) is genuinely functional client-side logic, not
mocked. If you don't pass `onInsightAction`, clicking a card's CTA just logs to the console so the
component still visibly "works" during development.
