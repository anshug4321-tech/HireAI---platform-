import clsx, { type ClassValue } from "clsx";

export function cn(...inputs: ClassValue[]): string {
  return clsx(inputs);
}

/**
 * Formats an ISO timestamp as a short relative string ("5m ago", "3h ago",
 * "2d ago"), falling back to a plain date once it's more than a week old.
 * Pure function — no Date.now() side effect leaking into a component body,
 * which keeps it easy to unit test by passing an explicit `now`.
 */
export function formatRelativeTime(iso: string, now: Date = new Date()): string {
  const then = new Date(iso);
  const diffMs = now.getTime() - then.getTime();
  const diffMinutes = Math.round(diffMs / 60000);

  if (diffMinutes < 1) return "Just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;

  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;

  const diffDays = Math.round(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;

  return then.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/** Clamps a confidence score into the valid 0–100 display range. */
export function clampConfidence(score: number): number {
  if (Number.isNaN(score)) return 0;
  return Math.min(100, Math.max(0, score));
}
