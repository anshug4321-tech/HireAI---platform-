import {
  CalendarCheck,
  AlertTriangle,
  TrendingUp,
  Sparkles,
  Users,
  Target,
  ShieldAlert,
  Zap,
} from "lucide-react";
import type { AIInsight } from "@/types/insight";

/** Produces an ISO timestamp N minutes before now, so the mock data always reads as fresh. */
function minutesAgo(minutes: number): string {
  return new Date(Date.now() - minutes * 60_000).toISOString();
}

export const MOCK_INSIGHTS: AIInsight[] = [
  {
    id: "insight-01",
    title: "Schedule an interview with John Doe",
    description:
      "John's profile scores a 96% match for the Senior Backend Engineer role based on skills, experience, and past interview signals. He's been in the pipeline for 4 days — candidates this strong typically get competing offers fast.",
    category: "recommendation",
    priority: "high",
    confidenceScore: 96,
    createdAt: minutesAgo(12),
    icon: CalendarCheck,
    ctaLabel: "Schedule interview",
  },
  {
    id: "insight-02",
    title: "Backend Engineer role has low candidate quality",
    description:
      "The last 14 applicants for Backend Engineer averaged a 41% skills match, well below your 70% pipeline average. Consider revisiting the job description or widening your sourcing channels.",
    category: "alert",
    priority: "high",
    confidenceScore: 91,
    createdAt: minutesAgo(38),
    icon: AlertTriangle,
    ctaLabel: "Review job posting",
  },
  {
    id: "insight-03",
    title: "Offer acceptance probability is 92%",
    description:
      "Based on comparable offers, negotiation tone, and response time, Priya Nair is highly likely to accept the Product Designer offer if extended within the next 2 business days.",
    category: "forecast",
    priority: "medium",
    confidenceScore: 92,
    createdAt: minutesAgo(55),
    icon: Target,
    ctaLabel: "View forecast details",
  },
  {
    id: "insight-04",
    title: "Hiring velocity increased by 18%",
    description:
      "Average time-to-offer dropped from 21 to 17.2 days this month, driven mostly by faster HR review turnaround on the Engineering and Design pipelines.",
    category: "performance",
    priority: "low",
    confidenceScore: 87,
    createdAt: minutesAgo(90),
    icon: TrendingUp,
    ctaLabel: "View full report",
  },
  {
    id: "insight-05",
    title: "3 candidates have an AI Match above 95%",
    description:
      "Amara Osei, Liam Chen, and Diego Fernández all scored above 95% for currently open roles this week. None have been contacted in the last 48 hours.",
    category: "suggestion",
    priority: "medium",
    confidenceScore: 95,
    createdAt: minutesAgo(140),
    icon: Sparkles,
    ctaLabel: "Review candidates",
  },
  {
    id: "insight-06",
    title: "Elevated proctoring flags on QA Engineer interviews",
    description:
      "4 of the last 9 QA Engineer interviews triggered tab-switch or paste-detection flags — roughly triple the platform average. Worth a manual transcript review before advancing anyone flagged.",
    category: "alert",
    priority: "medium",
    confidenceScore: 84,
    createdAt: minutesAgo(210),
    icon: ShieldAlert,
    ctaLabel: "Review flagged sessions",
  },
  {
    id: "insight-07",
    title: "Referral candidates are converting 2.3x faster",
    description:
      "Candidates sourced via employee referral are reaching offer stage in 9 days on average, versus 21 days for job-board applicants. Consider promoting the referral program internally this quarter.",
    category: "suggestion",
    priority: "low",
    confidenceScore: 89,
    createdAt: minutesAgo(320),
    icon: Users,
    ctaLabel: "See sourcing breakdown",
  },
  {
    id: "insight-08",
    title: "Interview-to-offer rate up sharply for Design",
    description:
      "The Design team's interview-to-offer conversion rate rose to 34% this cycle, up from 19% last quarter — the highest of any department, likely tied to the new structured scorecard.",
    category: "performance",
    priority: "low",
    confidenceScore: 93,
    createdAt: minutesAgo(480),
    icon: Zap,
    ctaLabel: "View department trends",
  },
];
