import type { LucideIcon } from "lucide-react";

/**
 * The five kinds of insight the AI engine can produce. Kept as a union
 * (not a plain string) so every switch/lookup over it is exhaustively
 * checked by the compiler.
 */
export type InsightCategory =
  | "recommendation"
  | "alert"
  | "forecast"
  | "suggestion"
  | "performance";

export type InsightPriority = "high" | "medium" | "low";

export interface AIInsight {
  id: string;
  title: string;
  description: string;
  category: InsightCategory;
  priority: InsightPriority;
  /** 0–100. Values outside that range are clamped defensively at render time. */
  confidenceScore: number;
  /** ISO 8601 timestamp of when the insight was generated. */
  createdAt: string;
  icon: LucideIcon;
  ctaLabel: string;
}

export const INSIGHT_CATEGORIES: readonly InsightCategory[] = [
  "recommendation",
  "alert",
  "forecast",
  "suggestion",
  "performance",
] as const;

export interface CategoryMeta {
  label: string;
  icon: LucideIcon;
  /** Tailwind classes for the small category badge. */
  className: string;
}

export interface PriorityMeta {
  label: string;
  /** Tailwind classes for the priority badge (background + text). */
  className: string;
  /** Tailwind class for the small status dot shown inside the badge. */
  dotClassName: string;
}
