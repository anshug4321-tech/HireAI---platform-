"use client";

import * as React from "react";
import { useId } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { AIInsight } from "@/types/insight";
import { formatRelativeTime } from "@/lib/utils";
import { PriorityBadge } from "./PriorityBadge";
import { CategoryBadge, CATEGORY_META } from "./CategoryBadge";
import { ConfidenceCircle } from "./ConfidenceCircle";

interface InsightCardProps {
  insight: AIInsight;
  /** Position in the currently-rendered list — drives the stagger delay only, nothing else. */
  index: number;
  onAction: (insight: AIInsight) => void;
}

const MAX_STAGGER_DELAY = 0.4;
const STAGGER_STEP = 0.05;

function InsightCardBase({ insight, index, onAction }: InsightCardProps) {
  const titleId = useId();
  const prefersReducedMotion = useReducedMotion();
  const Icon = insight.icon;
  const categoryTone = CATEGORY_META[insight.category].className;
  const delay = Math.min(index * STAGGER_STEP, MAX_STAGGER_DELAY);

  return (
    <motion.article
      aria-labelledby={titleId}
      initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.4, delay, ease: "easeOut" }}
      whileHover={prefersReducedMotion ? undefined : { y: -4 }}
      className="group flex h-full flex-col gap-4 rounded-2xl border border-black/[0.06] bg-white p-5 shadow-card transition-shadow duration-200 hover:shadow-glow focus-within:shadow-glow dark:border-white/[0.06] dark:bg-abyss-surface"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${categoryTone}`}
            aria-hidden="true"
          >
            <Icon size={18} />
          </span>
          <div className="min-w-0">
            <h3 id={titleId} className="font-display text-sm font-semibold leading-snug text-ink dark:text-white">
              {insight.title}
            </h3>
            <p className="mt-0.5 text-xs text-mist dark:text-white/40">
              <time dateTime={insight.createdAt}>{formatRelativeTime(insight.createdAt)}</time>
            </p>
          </div>
        </div>

        <ConfidenceCircle score={insight.confidenceScore} delay={delay + 0.1} />
      </div>

      <p className="line-clamp-3 flex-1 text-sm leading-relaxed text-mist dark:text-white/60">
        {insight.description}
      </p>

      <div className="flex flex-wrap gap-2">
        <PriorityBadge priority={insight.priority} />
        <CategoryBadge category={insight.category} />
      </div>

      <div className="mt-auto flex items-center justify-end border-t border-black/[0.05] pt-3 dark:border-white/[0.06]">
        <motion.button
          type="button"
          onClick={() => onAction(insight)}
          whileHover={prefersReducedMotion ? undefined : { scale: 1.03 }}
          whileTap={prefersReducedMotion ? undefined : { scale: 0.97 }}
          aria-label={`${insight.ctaLabel}: ${insight.title}`}
          className="inline-flex items-center gap-1.5 rounded-lg bg-iris-gradient px-3.5 py-2 text-xs font-semibold text-white shadow-sm transition-shadow hover:shadow-glow focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-iris-500"
        >
          {insight.ctaLabel}
          <ArrowUpRight size={14} aria-hidden="true" />
        </motion.button>
      </div>
    </motion.article>
  );
}

export const InsightCard = React.memo(InsightCardBase);
