"use client";

import * as React from "react";
import { useEffect, useState } from "react";
import { animate, useReducedMotion } from "framer-motion";
import { clampConfidence } from "@/lib/utils";

interface ConfidenceCircleProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  /** Stagger delay in seconds, so a grid of cards doesn't animate in unison. */
  delay?: number;
}

/** Ring color scales with confidence — high confidence reads as "good news" green. */
function toneForScore(score: number): { ring: string; track: string } {
  if (score >= 90) return { ring: "#3D9670", track: "#3D967026" };
  if (score >= 80) return { ring: "#4A5FFF", track: "#4A5FFF26" };
  return { ring: "#D97706", track: "#D9770626" };
}

function ConfidenceCircleBase({ score, size = 56, strokeWidth = 5, delay = 0 }: ConfidenceCircleProps) {
  const clamped = clampConfidence(score);
  const prefersReducedMotion = useReducedMotion();
  const [displayValue, setDisplayValue] = useState(prefersReducedMotion ? clamped : 0);

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const tone = toneForScore(clamped);

  useEffect(() => {
    if (prefersReducedMotion) {
      setDisplayValue(clamped);
      return;
    }
    // A single tweened value drives both the ring sweep and the number
    // beneath it, so the two can never visibly drift out of sync.
    const controls = animate(0, clamped, {
      duration: 1.1,
      delay,
      ease: "easeOut",
      onUpdate: (value) => setDisplayValue(Math.round(value)),
    });
    return () => controls.stop();
  }, [clamped, delay, prefersReducedMotion]);

  const offset = circumference - (circumference * displayValue) / 100;

  return (
    <div
      className="relative shrink-0"
      style={{ width: size, height: size }}
      role="img"
      aria-label={`AI confidence score: ${clamped}%`}
    >
      <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={tone.track} strokeWidth={strokeWidth} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={tone.ring}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          style={{ strokeDashoffset: offset, transition: prefersReducedMotion ? "none" : undefined }}
        />
      </svg>
      <span
        aria-hidden="true"
        className="absolute inset-0 flex items-center justify-center font-mono text-[11px] font-semibold text-ink dark:text-white"
      >
        {displayValue}%
      </span>
    </div>
  );
}

export const ConfidenceCircle = React.memo(ConfidenceCircleBase);
