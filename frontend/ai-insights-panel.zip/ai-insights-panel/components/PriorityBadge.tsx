import * as React from "react";
import type { InsightPriority, PriorityMeta } from "@/types/insight";
import { cn } from "@/lib/utils";

const PRIORITY_META: Record<InsightPriority, PriorityMeta> = {
  high: {
    label: "High priority",
    className: "bg-danger-50 text-danger-500 dark:bg-danger-500/10 dark:text-danger-500",
    dotClassName: "bg-danger-500",
  },
  medium: {
    label: "Medium priority",
    className: "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400",
    dotClassName: "bg-amber-500",
  },
  low: {
    label: "Low priority",
    className: "bg-success-50 text-success-500 dark:bg-success-500/10 dark:text-success-500",
    dotClassName: "bg-success-500",
  },
};

const PRIORITY_SHORT_LABEL: Record<InsightPriority, string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
};

interface PriorityBadgeProps {
  priority: InsightPriority;
}

function PriorityBadgeBase({ priority }: PriorityBadgeProps) {
  const meta = PRIORITY_META[priority];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        meta.className
      )}
      // aria-label supplies the full "High priority" accessible name and
      // takes precedence over the abbreviated visible text below, so
      // screen readers hear one clean phrase instead of "High High priority".
      aria-label={meta.label}
    >
      <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", meta.dotClassName)} aria-hidden="true" />
      <span aria-hidden="true">{PRIORITY_SHORT_LABEL[priority]}</span>
    </span>
  );
}

export const PriorityBadge = React.memo(PriorityBadgeBase);
