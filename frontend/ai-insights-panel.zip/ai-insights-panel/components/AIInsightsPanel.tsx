"use client";

import * as React from "react";
import { useCallback, useDeferredValue, useMemo, useState } from "react";
import { Search, Sparkles, ChevronDown } from "lucide-react";
import type { AIInsight, InsightCategory } from "@/types/insight";
import { INSIGHT_CATEGORIES } from "@/types/insight";
import { MOCK_INSIGHTS } from "@/data/mock-insights";
import { CATEGORY_META } from "./CategoryBadge";
import { InsightCard } from "./InsightCard";
import { InsightCardSkeletonGrid } from "./InsightCardSkeleton";
import { EmptyState, NoMatchesState } from "./EmptyState";

type CategoryFilter = InsightCategory | "all";

export interface AIInsightsPanelProps {
  /** Defaults to bundled mock data so the component renders meaningfully with zero props. */
  insights?: AIInsight[];
  /** Drive this from your real data-fetching state. Defaults to false. */
  isLoading?: boolean;
  /** Called when a card's CTA is clicked. Defaults to a console log if omitted. */
  onInsightAction?: (insight: AIInsight) => void;
  className?: string;
}

function matchesQuery(insight: AIInsight, query: string): boolean {
  if (!query) return true;
  const haystack = `${insight.title} ${insight.description} ${insight.category}`.toLowerCase();
  return haystack.includes(query.toLowerCase());
}

function AIInsightsPanel({
  insights = MOCK_INSIGHTS,
  isLoading = false,
  onInsightAction,
  className = "",
}: AIInsightsPanelProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");

  // Keeps keystrokes snappy even if `insights` were a much larger list —
  // filtering runs against the deferred value, not every keystroke directly.
  const deferredQuery = useDeferredValue(searchQuery);

  const filteredInsights = useMemo(() => {
    return insights.filter(
      (insight) =>
        (categoryFilter === "all" || insight.category === categoryFilter) &&
        matchesQuery(insight, deferredQuery)
    );
  }, [insights, categoryFilter, deferredQuery]);

  const handleAction = useCallback(
    (insight: AIInsight) => {
      if (onInsightAction) {
        onInsightAction(insight);
      } else {
        // No handler was wired up — this is a UI-only default so the
        // component still "works" out of the box. Replace by passing
        // `onInsightAction` from the consuming page.
        console.info("[AIInsightsPanel] View details:", insight.id);
      }
    },
    [onInsightAction]
  );

  const clearFilters = useCallback(() => {
    setSearchQuery("");
    setCategoryFilter("all");
  }, []);

  const hasAnyInsights = insights.length > 0;
  const hasVisibleInsights = filteredInsights.length > 0;
  const isFiltering = searchQuery.trim().length > 0 || categoryFilter !== "all";

  return (
    <section
      aria-label="AI Insights"
      className={`rounded-3xl border border-black/[0.06] bg-cloud/60 p-5 dark:border-white/[0.06] dark:bg-abyss-surface/40 sm:p-6 ${className}`}
    >
      <header className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <span
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-iris-gradient text-white shadow-glow"
            aria-hidden="true"
          >
            <Sparkles size={18} />
          </span>
          <div>
            <h2 className="font-display text-lg font-bold text-ink dark:text-white">AI Insights</h2>
            <p className="text-xs text-mist dark:text-white/40">
              {hasAnyInsights
                ? `${insights.length} insight${insights.length === 1 ? "" : "s"} generated from candidate data`
                : "Nothing to show yet"}
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <div className="relative">
            <Search
              size={15}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-mist dark:text-white/40"
              aria-hidden="true"
            />
            <label htmlFor="ai-insights-search" className="sr-only">
              Search insights
            </label>
            <input
              id="ai-insights-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search insights…"
              disabled={!hasAnyInsights || isLoading}
              className="w-full rounded-lg border border-black/10 bg-white py-2 pl-9 pr-3 text-sm text-ink outline-none transition-colors placeholder:text-mist/60 focus:border-iris-400 disabled:cursor-not-allowed disabled:opacity-50 dark:border-white/10 dark:bg-abyss-raised dark:text-white sm:w-56"
            />
          </div>

          <div className="relative">
            <label htmlFor="ai-insights-category" className="sr-only">
              Filter by category
            </label>
            <select
              id="ai-insights-category"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as CategoryFilter)}
              disabled={!hasAnyInsights || isLoading}
              className="w-full appearance-none rounded-lg border border-black/10 bg-white py-2 pl-3 pr-8 text-sm text-ink outline-none transition-colors focus:border-iris-400 disabled:cursor-not-allowed disabled:opacity-50 dark:border-white/10 dark:bg-abyss-raised dark:text-white sm:w-44"
            >
              <option value="all">All categories</option>
              {INSIGHT_CATEGORIES.map((category) => (
                <option key={category} value={category}>
                  {CATEGORY_META[category].label}
                </option>
              ))}
            </select>
            <ChevronDown
              size={14}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-mist dark:text-white/40"
              aria-hidden="true"
            />
          </div>
        </div>
      </header>

      {isLoading ? (
        <InsightCardSkeletonGrid />
      ) : !hasAnyInsights ? (
        <EmptyState />
      ) : !hasVisibleInsights ? (
        <NoMatchesState onClear={clearFilters} />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filteredInsights.map((insight, index) => (
            <InsightCard key={insight.id} insight={insight} index={index} onAction={handleAction} />
          ))}
        </div>
      )}

      {/* Polite live region so screen reader users hear result-count changes
          as they type or change the filter, without being interrupted mid-keystroke. */}
      <p className="sr-only" role="status" aria-live="polite">
        {isLoading
          ? "Loading insights"
          : isFiltering
            ? `${filteredInsights.length} insight${filteredInsights.length === 1 ? "" : "s"} match your search`
            : ""}
      </p>
    </section>
  );
}

export default React.memo(AIInsightsPanel);
