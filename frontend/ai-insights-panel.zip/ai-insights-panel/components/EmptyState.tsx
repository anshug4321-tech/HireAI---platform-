import { BrainCircuit, SearchX } from "lucide-react";

/** Shown when the AI hasn't produced any insights yet. */
export function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-black/10 px-6 py-16 text-center dark:border-white/10">
      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-iris-gradient-soft text-iris-600 dark:bg-white/5 dark:text-iris-400">
        <BrainCircuit size={26} aria-hidden="true" />
      </div>
      <h3 className="font-display text-lg font-semibold text-ink dark:text-white">
        No AI Insights Available
      </h3>
      <p className="mt-1.5 max-w-xs text-sm text-mist dark:text-white/50">
        Insights will appear after AI analyzes candidate data.
      </p>
    </div>
  );
}

/** Shown when insights exist but the current search/filter combination matches none of them. */
export function NoMatchesState({ onClear }: { onClear: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-black/10 px-6 py-16 text-center dark:border-white/10">
      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-cloud text-mist dark:bg-white/5 dark:text-white/50">
        <SearchX size={24} aria-hidden="true" />
      </div>
      <h3 className="font-display text-lg font-semibold text-ink dark:text-white">
        No insights match your search
      </h3>
      <p className="mt-1.5 max-w-xs text-sm text-mist dark:text-white/50">
        Try a different keyword or switch back to All categories.
      </p>
      <button
        type="button"
        onClick={onClear}
        className="mt-5 rounded-lg border border-black/10 px-4 py-2 text-sm font-medium text-ink transition-colors hover:bg-cloud dark:border-white/10 dark:text-white dark:hover:bg-white/5"
      >
        Clear search &amp; filters
      </button>
    </div>
  );
}
