import * as React from "react";
import { cn } from "@/lib/utils";

function Bone({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-md bg-black/[0.06] dark:bg-white/[0.08]", className)} />;
}

function InsightCardSkeletonBase() {
  return (
    <div
      className="flex h-full flex-col gap-4 rounded-2xl border border-black/[0.06] bg-white p-5 dark:border-white/[0.06] dark:bg-abyss-surface"
      aria-hidden="true"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <Bone className="h-10 w-10 rounded-xl" />
          <div className="space-y-2">
            <Bone className="h-3.5 w-32" />
            <Bone className="h-3 w-20" />
          </div>
        </div>
        <Bone className="h-12 w-12 rounded-full" />
      </div>

      <div className="space-y-2">
        <Bone className="h-3 w-full" />
        <Bone className="h-3 w-[85%]" />
        <Bone className="h-3 w-[60%]" />
      </div>

      <div className="flex gap-2">
        <Bone className="h-6 w-24 rounded-full" />
        <Bone className="h-6 w-20 rounded-full" />
      </div>

      <div className="mt-auto flex items-center justify-between pt-1">
        <Bone className="h-3 w-16" />
        <Bone className="h-8 w-28 rounded-lg" />
      </div>
    </div>
  );
}

export const InsightCardSkeleton = React.memo(InsightCardSkeletonBase);

/** Renders `count` skeleton cards — the shape a loading grid actually needs. */
export function InsightCardSkeletonGrid({ count = 6 }: { count?: number }) {
  return (
    <div
      className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3"
      role="status"
      aria-label="Loading AI insights"
    >
      {Array.from({ length: count }).map((_, i) => (
        <InsightCardSkeleton key={i} />
      ))}
    </div>
  );
}
