import * as React from "react";
import { Lightbulb, AlertCircle, LineChart, Wand2, Gauge } from "lucide-react";
import type { CategoryMeta, InsightCategory } from "@/types/insight";
import { cn } from "@/lib/utils";

export const CATEGORY_META: Record<InsightCategory, CategoryMeta> = {
  recommendation: {
    label: "Recommendation",
    icon: Lightbulb,
    className: "bg-iris-50 text-iris-600 dark:bg-iris-500/10 dark:text-iris-400",
  },
  alert: {
    label: "Alert",
    icon: AlertCircle,
    className: "bg-danger-50 text-danger-500 dark:bg-danger-500/10 dark:text-danger-500",
  },
  forecast: {
    label: "Forecast",
    icon: LineChart,
    className: "bg-violet-500/10 text-violet-600 dark:bg-violet-500/15 dark:text-violet-400",
  },
  suggestion: {
    label: "Suggestion",
    icon: Wand2,
    className: "bg-cloud text-mist dark:bg-white/5 dark:text-white/60",
  },
  performance: {
    label: "Performance",
    icon: Gauge,
    className: "bg-success-50 text-success-500 dark:bg-success-500/10 dark:text-success-500",
  },
};

interface CategoryBadgeProps {
  category: InsightCategory;
}

function CategoryBadgeBase({ category }: CategoryBadgeProps) {
  const meta = CATEGORY_META[category];
  const Icon = meta.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        meta.className
      )}
    >
      <Icon size={12} aria-hidden="true" />
      {meta.label}
    </span>
  );
}

export const CategoryBadge = React.memo(CategoryBadgeBase);
