"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/lib/theme-provider";

export function ThemeToggle({ collapsed = false }: { collapsed?: boolean }) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";
  const prefersReducedMotion = useReducedMotion();
  const iconTransition = prefersReducedMotion
    ? { duration: 0 }
    : { duration: 0.35, ease: "easeInOut" as const };

  return (
    <button
      onClick={toggleTheme}
      aria-pressed={isDark}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Switch to light mode" : "Switch to dark mode"}
      className={`group relative flex items-center gap-2.5 overflow-hidden rounded-xl border border-black/[0.06] bg-white/60 px-3 py-2.5 text-mist transition-colors hover:text-ink dark:border-white/[0.08] dark:bg-white/[0.03] dark:text-white/50 dark:hover:text-white/90 ${
        collapsed ? "w-10 justify-center px-0" : "w-full"
      }`}
    >
      <span className="relative flex h-4 w-4 shrink-0 items-center justify-center" aria-hidden="true">
        <motion.span
          initial={false}
          animate={{ rotate: isDark ? 180 : 0, opacity: isDark ? 0 : 1, scale: isDark ? 0.4 : 1 }}
          transition={iconTransition}
          className="absolute"
        >
          <Sun size={16} />
        </motion.span>
        <motion.span
          initial={false}
          animate={{ rotate: isDark ? 0 : -180, opacity: isDark ? 1 : 0, scale: isDark ? 1 : 0.4 }}
          transition={iconTransition}
          className="absolute"
        >
          <Moon size={16} />
        </motion.span>
      </span>
      <span className={`text-xs font-medium ${collapsed ? "sr-only" : ""}`}>
        {isDark ? "Dark mode" : "Light mode"}
      </span>
    </button>
  );
}
