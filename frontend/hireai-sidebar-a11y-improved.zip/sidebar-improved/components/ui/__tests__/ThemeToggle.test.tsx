import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ThemeToggle } from "../ThemeToggle";

const toggleTheme = vi.fn();
let mockTheme: "light" | "dark" = "light";

vi.mock("@/lib/theme-provider", () => ({
  useTheme: () => ({ theme: mockTheme, toggleTheme, setTheme: vi.fn() }),
}));

describe("ThemeToggle", () => {
  it("reflects the current theme via aria-pressed and label", () => {
    mockTheme = "light";
    render(<ThemeToggle />);
    const button = screen.getByRole("button", { name: /switch to dark mode/i });
    expect(button).toHaveAttribute("aria-pressed", "false");
  });

  it("flips aria-pressed and the label when already dark", () => {
    mockTheme = "dark";
    render(<ThemeToggle />);
    const button = screen.getByRole("button", { name: /switch to light mode/i });
    expect(button).toHaveAttribute("aria-pressed", "true");
  });

  it("calls toggleTheme on click", async () => {
    mockTheme = "light";
    const user = userEvent.setup();
    render(<ThemeToggle />);
    await user.click(screen.getByRole("button"));
    expect(toggleTheme).toHaveBeenCalledTimes(1);
  });

  it("keeps an accessible name when collapsed", () => {
    mockTheme = "light";
    render(<ThemeToggle collapsed />);
    expect(screen.getByRole("button", { name: /switch to dark mode/i })).toBeInTheDocument();
  });
});
