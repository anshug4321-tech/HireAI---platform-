import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useRef } from "react";
import { useSidebarKeyboardNav } from "../useSidebarKeyboardNav";

function TestNav() {
  const ref = useRef<HTMLElement>(null);
  useSidebarKeyboardNav(ref);
  return (
    // eslint-disable-next-line jsx-a11y/no-redundant-roles
    <nav ref={ref as React.RefObject<HTMLElement>} aria-label="Test nav">
      <a href="#a" data-sidebar-nav-item>
        First
      </a>
      <a href="#b" data-sidebar-nav-item>
        Second
      </a>
      <a href="#c" data-sidebar-nav-item>
        Third
      </a>
    </nav>
  );
}

describe("useSidebarKeyboardNav", () => {
  it("moves focus to the next item on ArrowDown and wraps at the end", async () => {
    const user = userEvent.setup();
    render(<TestNav />);

    const first = screen.getByRole("link", { name: "First" });
    const second = screen.getByRole("link", { name: "Second" });
    const third = screen.getByRole("link", { name: "Third" });

    first.focus();
    await user.keyboard("{ArrowDown}");
    expect(second).toHaveFocus();

    await user.keyboard("{ArrowDown}");
    expect(third).toHaveFocus();

    await user.keyboard("{ArrowDown}");
    expect(first).toHaveFocus();
  });

  it("moves focus to the previous item on ArrowUp and wraps at the start", async () => {
    const user = userEvent.setup();
    render(<TestNav />);

    const first = screen.getByRole("link", { name: "First" });
    const third = screen.getByRole("link", { name: "Third" });

    first.focus();
    await user.keyboard("{ArrowUp}");
    expect(third).toHaveFocus();
  });

  it("jumps to the first/last item on Home/End", async () => {
    const user = userEvent.setup();
    render(<TestNav />);

    const first = screen.getByRole("link", { name: "First" });
    const second = screen.getByRole("link", { name: "Second" });
    const third = screen.getByRole("link", { name: "Third" });

    second.focus();
    await user.keyboard("{End}");
    expect(third).toHaveFocus();

    await user.keyboard("{Home}");
    expect(first).toHaveFocus();
  });
});
