import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useRef, useState } from "react";
import { useFocusTrap } from "../useFocusTrap";

function TestDialog() {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  useFocusTrap(containerRef as React.RefObject<HTMLElement>, open);

  return (
    <div>
      <button onClick={() => setOpen(true)}>Open trigger</button>
      {open && (
        <div ref={containerRef} role="dialog" aria-label="Test dialog">
          <button data-autofocus onClick={() => setOpen(false)}>
            Close
          </button>
          <button>Middle</button>
          <a href="#last">Last link</a>
        </div>
      )}
    </div>
  );
}

describe("useFocusTrap", () => {
  it("moves focus to the [data-autofocus] element when activated", async () => {
    const user = userEvent.setup();
    render(<TestDialog />);

    await user.click(screen.getByRole("button", { name: "Open trigger" }));
    expect(screen.getByRole("button", { name: "Close" })).toHaveFocus();
  });

  it("wraps Tab from the last focusable element back to the first", async () => {
    const user = userEvent.setup();
    render(<TestDialog />);
    await user.click(screen.getByRole("button", { name: "Open trigger" }));

    const close = screen.getByRole("button", { name: "Close" });
    const last = screen.getByRole("link", { name: "Last link" });

    last.focus();
    await user.tab();
    expect(close).toHaveFocus();
  });

  it("wraps Shift+Tab from the first focusable element to the last", async () => {
    const user = userEvent.setup();
    render(<TestDialog />);
    await user.click(screen.getByRole("button", { name: "Open trigger" }));

    const close = screen.getByRole("button", { name: "Close" });
    const last = screen.getByRole("link", { name: "Last link" });

    close.focus();
    await user.tab({ shift: true });
    expect(last).toHaveFocus();
  });

  it("restores focus to the trigger once the dialog closes", async () => {
    const user = userEvent.setup();
    render(<TestDialog />);

    const trigger = screen.getByRole("button", { name: "Open trigger" });
    await user.click(trigger);
    await user.click(screen.getByRole("button", { name: "Close" }));

    expect(trigger).toHaveFocus();
  });
});
