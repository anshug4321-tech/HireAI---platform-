"use client";

import { useEffect, useRef } from "react";

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button:not([disabled])",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  '[tabindex]:not([tabindex="-1"])',
].join(",");

/**
 * Traps Tab/Shift+Tab focus inside `containerRef` while `active` is true,
 * moves focus into the container on activation, and restores focus to
 * whatever was focused beforehand once deactivated.
 *
 * Deliberately has no rendering output and no dependency on any specific
 * component — it only touches the DOM node it's given — so it can be
 * exercised in a unit test with a plain jsdom container instead of a full
 * component tree.
 */
export function useFocusTrap(containerRef: React.RefObject<HTMLElement>, active: boolean) {
  const previouslyFocused = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!active) return;
    const container = containerRef.current;
    if (!container) return;

    previouslyFocused.current = document.activeElement as HTMLElement | null;

    const getFocusable = () =>
      Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
        (el) => el.offsetParent !== null
      );

    // Move focus into the dialog. Prefer an element explicitly marked as the
    // initial focus target; otherwise fall back to the first focusable child.
    const initial =
      container.querySelector<HTMLElement>("[data-autofocus]") ?? getFocusable()[0];
    initial?.focus();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const focusable = getFocusable();
      if (focusable.length === 0) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const current = document.activeElement;

      if (e.shiftKey && current === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && current === last) {
        e.preventDefault();
        first.focus();
      }
    };

    container.addEventListener("keydown", onKeyDown);
    return () => {
      container.removeEventListener("keydown", onKeyDown);
      // Restore focus to whatever triggered the dialog, if it's still around.
      previouslyFocused.current?.focus?.();
    };
  }, [active, containerRef]);
}
