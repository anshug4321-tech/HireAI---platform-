"use client";

import { useEffect } from "react";

const ITEM_SELECTOR = "[data-sidebar-nav-item]";

/**
 * Adds ArrowUp/ArrowDown/Home/End roving focus across every element matching
 * `[data-sidebar-nav-item]` inside `containerRef`, in addition to normal Tab
 * order (Tab order is left untouched — this only kicks in once focus is
 * already on one of the nav links).
 *
 * Pure DOM/event-listener logic with no visual output, which keeps it cheap
 * to unit test against a bare jsdom container instead of the full sidebar.
 */
export function useSidebarKeyboardNav(containerRef: React.RefObject<HTMLElement>) {
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (!target.matches(ITEM_SELECTOR)) return;

      const items = Array.from(container.querySelectorAll<HTMLElement>(ITEM_SELECTOR));
      const index = items.indexOf(target);
      if (index === -1) return;

      let nextIndex: number | null = null;
      switch (e.key) {
        case "ArrowDown":
          nextIndex = (index + 1) % items.length;
          break;
        case "ArrowUp":
          nextIndex = (index - 1 + items.length) % items.length;
          break;
        case "Home":
          nextIndex = 0;
          break;
        case "End":
          nextIndex = items.length - 1;
          break;
        default:
          return;
      }

      e.preventDefault();
      items[nextIndex]?.focus();
    };

    container.addEventListener("keydown", onKeyDown);
    return () => container.removeEventListener("keydown", onKeyDown);
  }, [containerRef]);
}
