"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, useReducedMotion } from "framer-motion";
import type { NavItem } from "./nav-config";
import { isNavItemActive } from "./nav-config";

export function SidebarItem({
  item,
  collapsed,
  activePillLayoutId,
}: {
  item: NavItem;
  collapsed: boolean;
  /** Shared framer-motion layoutId so the highlight glides between items. */
  activePillLayoutId: string;
}) {
  const pathname = usePathname();
  const isActive = isNavItemActive(pathname, item.href);
  const prefersReducedMotion = useReducedMotion();
  const Icon = item.icon;

  const badgeText = item.badge ? ` (${item.badge} new)` : "";

  return (
    <Link
      href={item.href}
      aria-current={isActive ? "page" : undefined}
      data-sidebar-nav-item
      className={`group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
        isActive
          ? "text-iris-600 dark:text-white"
          : "text-mist hover:text-ink dark:text-white/50 dark:hover:text-white/90"
      } ${collapsed ? "justify-center px-0" : ""}`}
    >
      {isActive && (
        <motion.span
          layoutId={activePillLayoutId}
          transition={prefersReducedMotion ? { duration: 0 } : { type: "spring", stiffness: 420, damping: 34 }}
          className="absolute inset-0 rounded-xl bg-iris-gradient-soft dark:bg-white/[0.08]"
          aria-hidden="true"
        />
      )}

      <span className="relative flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
        <Icon size={18} />
      </span>

      {/*
        The label stays in the DOM at all times (never conditionally
        unmounted) so collapsed nav items keep a real accessible name for
        screen readers instead of relying on the hover-only tooltip below.
        It's only ever visually hidden via `sr-only`.
      */}
      <span className={`relative truncate ${collapsed ? "sr-only" : ""}`}>
        {item.label}
        {badgeText && <span className="sr-only">{badgeText}</span>}
      </span>

      {!collapsed && item.badge ? (
        <span
          className="relative ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-iris-gradient px-1.5 text-[11px] font-semibold text-white"
          aria-hidden="true"
        >
          {item.badge}
        </span>
      ) : null}

      {/*
        Visual-only tooltip for the collapsed (icon-only) rail state. It's
        `aria-hidden` because the accessible name already comes from the
        sr-only label above — this is purely a sighted-user affordance, shown
        on hover *and* keyboard focus so keyboard users aren't left guessing
        what an icon means.
      */}
      {collapsed && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute left-full ml-3 whitespace-nowrap rounded-lg bg-ink px-2.5 py-1.5 text-xs font-medium text-white opacity-0 shadow-card transition-opacity duration-150 group-hover:opacity-100 group-focus-visible:opacity-100 dark:bg-abyss-raised"
        >
          {item.label}
          {item.badge ? ` · ${item.badge}` : ""}
        </span>
      )}
    </Link>
  );
}
