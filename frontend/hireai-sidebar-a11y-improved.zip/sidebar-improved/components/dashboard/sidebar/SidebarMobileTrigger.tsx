"use client";

import { Menu } from "lucide-react";
import { useSidebar } from "./SidebarContext";

export function SidebarMobileTrigger({ className = "" }: { className?: string }) {
  const { mobileOpen, openMobile } = useSidebar();

  return (
    <button
      onClick={openMobile}
      aria-label="Open navigation"
      aria-haspopup="dialog"
      aria-expanded={mobileOpen}
      aria-controls="sidebar-mobile-drawer"
      className={`flex h-9 w-9 items-center justify-center rounded-lg text-mist hover:bg-cloud hover:text-ink dark:text-white/50 dark:hover:bg-white/5 dark:hover:text-white md:hidden ${className}`}
    >
      <Menu size={20} aria-hidden="true" />
    </button>
  );
}
