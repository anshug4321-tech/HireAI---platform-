"use client";

import { useRef } from "react";
import Link from "next/link";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ChevronsLeft, X } from "lucide-react";
import { NAV_SECTIONS, NAV_FOOTER_ITEM } from "./nav-config";
import { SidebarItem } from "./SidebarItem";
import { useSidebar } from "./SidebarContext";
import { useFocusTrap, useSidebarKeyboardNav } from "./hooks";
import { ThemeToggle } from "@/components/ui/ThemeToggle";

const RAIL_WIDTH = 264;
const RAIL_WIDTH_COLLAPSED = 76;
const DESKTOP_RAIL_ID = "sidebar-rail";
const MOBILE_DRAWER_ID = "sidebar-mobile-drawer";

/**
 * Pure presentational nav content, shared by the desktop rail and the mobile
 * drawer. Exported (rather than kept private) so it can be rendered and
 * asserted on in isolation in tests — e.g. "does it render one link per
 * nav-config entry" — without also mounting the motion/drawer chrome around it.
 */
export function SidebarContent({
  collapsed,
  navRef,
}: {
  collapsed: boolean;
  navRef?: React.RefObject<HTMLElement>;
}) {
  return (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div
        className={`flex h-16 shrink-0 items-center border-b border-black/[0.06] dark:border-white/[0.06] ${collapsed ? "justify-center px-0" : "px-5"}`}
      >
        <Link href="/dashboard" className="flex items-center gap-2.5 overflow-hidden">
          <span
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-iris-gradient text-sm font-bold text-white"
            aria-hidden="true"
          >
            H
          </span>
          <span className={`truncate font-display text-lg font-bold text-ink dark:text-white ${collapsed ? "sr-only" : ""}`}>
            HireAI
          </span>
        </Link>
      </div>

      {/* Nav */}
      <nav ref={navRef} aria-label="Primary" className="flex-1 space-y-6 overflow-y-auto px-3 py-5">
        {NAV_SECTIONS.map((section) => {
          const headingId = `sidebar-section-${section.id}`;
          return (
            <div key={section.id} role="group" aria-labelledby={headingId}>
              <p
                id={headingId}
                className={`mb-2 px-3 font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-mist/70 dark:text-white/30 ${collapsed ? "sr-only" : ""}`}
              >
                {section.label}
              </p>
              <div className="space-y-1">
                {section.items.map((item) => (
                  <SidebarItem
                    key={item.id}
                    item={item}
                    collapsed={collapsed}
                    activePillLayoutId="sidebar-active-pill"
                  />
                ))}
              </div>
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="shrink-0 space-y-1 border-t border-black/[0.06] px-3 py-4 dark:border-white/[0.06]">
        <SidebarItem item={NAV_FOOTER_ITEM} collapsed={collapsed} activePillLayoutId="sidebar-active-pill" />
        <ThemeToggle collapsed={collapsed} />
      </div>
    </div>
  );
}

export function Sidebar() {
  const { collapsed, toggleCollapsed, mobileOpen, closeMobile } = useSidebar();
  const prefersReducedMotion = useReducedMotion();
  const desktopNavRef = useRef<HTMLElement>(null);
  const mobileNavRef = useRef<HTMLElement>(null);
  const drawerRef = useRef<HTMLElement>(null);

  useSidebarKeyboardNav(desktopNavRef);
  useSidebarKeyboardNav(mobileNavRef);
  useFocusTrap(drawerRef, mobileOpen);

  const springTransition = prefersReducedMotion
    ? { duration: 0 }
    : { type: "spring" as const, stiffness: 340, damping: 34 };

  return (
    <>
      {/* Desktop rail */}
      <motion.aside
        id={DESKTOP_RAIL_ID}
        animate={{ width: collapsed ? RAIL_WIDTH_COLLAPSED : RAIL_WIDTH }}
        transition={springTransition}
        className="relative hidden shrink-0 border-r border-black/[0.06] bg-white/80 backdrop-blur-xl dark:border-white/[0.06] dark:bg-abyss-surface/80 md:block"
      >
        <SidebarContent collapsed={collapsed} navRef={desktopNavRef} />

        {/* Collapse toggle — floats on the rail's edge */}
        <button
          onClick={toggleCollapsed}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-expanded={!collapsed}
          aria-controls={DESKTOP_RAIL_ID}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="absolute -right-3 top-[4.25rem] flex h-6 w-6 items-center justify-center rounded-full border border-black/[0.08] bg-white text-mist shadow-card transition-colors hover:text-iris-600 dark:border-white/10 dark:bg-abyss-raised dark:text-white/50 dark:hover:text-white"
        >
          <motion.span
            animate={{ rotate: collapsed ? 180 : 0 }}
            transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.3, ease: "easeInOut" }}
            className="flex"
            aria-hidden="true"
          >
            <ChevronsLeft size={13} />
          </motion.span>
        </button>
      </motion.aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              key="overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.2 }}
              onClick={closeMobile}
              className="fixed inset-0 z-40 bg-ink/40 backdrop-blur-sm md:hidden"
              aria-hidden="true"
            />
            <motion.aside
              key="drawer"
              ref={drawerRef}
              id={MOBILE_DRAWER_ID}
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={prefersReducedMotion ? { duration: 0 } : { type: "spring", stiffness: 380, damping: 38 }}
              role="dialog"
              aria-modal="true"
              aria-label="Navigation"
              className="fixed inset-y-0 left-0 z-50 w-[80%] max-w-[288px] border-r border-black/[0.06] bg-white shadow-glow dark:border-white/[0.06] dark:bg-abyss-surface md:hidden"
            >
              <button
                onClick={closeMobile}
                aria-label="Close navigation"
                data-autofocus
                className="absolute right-3 top-4 flex h-8 w-8 items-center justify-center rounded-lg text-mist hover:bg-cloud hover:text-ink dark:text-white/50 dark:hover:bg-white/5 dark:hover:text-white"
              >
                <X size={18} aria-hidden="true" />
              </button>
              <SidebarContent collapsed={false} navRef={mobileNavRef} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
