import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  ListChecks,
  BarChart3,
  Settings,
} from "lucide-react";

export interface NavItem {
  id: string;
  label: string;
  href: string;
  icon: LucideIcon;
  badge?: number;
}

export interface NavSection {
  id: string;
  label: string;
  items: NavItem[];
}

// Swap hrefs/icons/badges here to match real routes — the Sidebar itself
// has no hardcoded routes, it only reads this config.
export const NAV_SECTIONS: NavSection[] = [
  {
    id: "overview",
    label: "Overview",
    items: [
      { id: "dashboard", label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { id: "candidates", label: "Candidates", href: "/dashboard/candidates", icon: Users },
    ],
  },
  {
    id: "hiring",
    label: "Hiring",
    items: [
      { id: "roles", label: "Job Roles", href: "/dashboard/roles", icon: Briefcase },
      { id: "questions", label: "Question Bank", href: "/dashboard/questions", icon: ListChecks },
    ],
  },
  {
    id: "insights",
    label: "Insights",
    items: [
      { id: "analytics", label: "Analytics", href: "/dashboard/analytics", icon: BarChart3 },
    ],
  },
];

export const NAV_FOOTER_ITEM: NavItem = {
  id: "settings",
  label: "Settings",
  href: "/dashboard/settings",
  icon: Settings,
};

/**
 * Whether a nav item should be shown as active for the given pathname.
 *
 * Pulled out as a plain function (no React, no hooks) specifically so it can
 * be unit tested with plain input/output assertions instead of needing to
 * render a component and mock `usePathname()`.
 *
 * `/dashboard` is matched exactly so it doesn't stay "active" for every
 * nested route; every other href matches on prefix so e.g. `/dashboard/candidates/42`
 * still highlights "Candidates".
 */
export function isNavItemActive(pathname: string, href: string): boolean {
  if (href === "/dashboard") return pathname === href;
  return pathname === href || pathname.startsWith(`${href}/`);
}
