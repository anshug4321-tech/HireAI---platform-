import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { LayoutDashboard } from "lucide-react";
import { SidebarItem } from "../SidebarItem";
import type { NavItem } from "../nav-config";

vi.mock("next/navigation", () => ({
  usePathname: () => "/dashboard",
}));

const item: NavItem = {
  id: "dashboard",
  label: "Dashboard",
  href: "/dashboard",
  icon: LayoutDashboard,
  badge: 3,
};

describe("SidebarItem", () => {
  it("marks the active route with aria-current", () => {
    render(<SidebarItem item={item} collapsed={false} activePillLayoutId="pill" />);
    expect(screen.getByRole("link", { name: /dashboard/i })).toHaveAttribute("aria-current", "page");
  });

  it("keeps an accessible name even when the rail is collapsed", () => {
    render(<SidebarItem item={item} collapsed activePillLayoutId="pill" />);
    // The visible label is sr-only, not removed — the link must still have
    // "Dashboard" as its accessible name for screen reader users.
    expect(screen.getByRole("link", { name: /dashboard/i })).toBeInTheDocument();
  });

  it("hides decorative elements (icon, badge, tooltip) from the accessibility tree", () => {
    render(<SidebarItem item={item} collapsed activePillLayoutId="pill" />);
    const link = screen.getByRole("link", { name: /dashboard/i });
    const hiddenDescendants = link.querySelectorAll('[aria-hidden="true"]');
    expect(hiddenDescendants.length).toBeGreaterThan(0);
  });
});
