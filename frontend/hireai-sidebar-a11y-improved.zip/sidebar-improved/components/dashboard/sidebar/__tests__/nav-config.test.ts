import { describe, expect, it } from "vitest";
import { isNavItemActive } from "../nav-config";

describe("isNavItemActive", () => {
  it("matches the dashboard home route only when the pathname is exact", () => {
    expect(isNavItemActive("/dashboard", "/dashboard")).toBe(true);
    expect(isNavItemActive("/dashboard/candidates", "/dashboard")).toBe(false);
  });

  it("matches nested routes for non-home items", () => {
    expect(isNavItemActive("/dashboard/candidates", "/dashboard/candidates")).toBe(true);
    expect(isNavItemActive("/dashboard/candidates/42", "/dashboard/candidates")).toBe(true);
  });

  it("does not match a different route that merely shares a prefix", () => {
    // e.g. "/dashboard/roles" must not light up for "/dashboard/roles-archive"
    expect(isNavItemActive("/dashboard/roles-archive", "/dashboard/roles")).toBe(false);
  });

  it("does not match unrelated routes", () => {
    expect(isNavItemActive("/dashboard/analytics", "/dashboard/roles")).toBe(false);
  });
});
