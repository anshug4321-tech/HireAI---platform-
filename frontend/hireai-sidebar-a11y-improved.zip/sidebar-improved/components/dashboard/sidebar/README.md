# HireAI — HR Dashboard Sidebar

A standalone, reusable sidebar module. It renders nothing on its own — wrap
whatever dashboard layout you build with `SidebarProvider`, then render
`<Sidebar />` next to your page content.

## Files

```
components/dashboard/sidebar/
  Sidebar.tsx                 Desktop collapsible rail + mobile drawer.
                               Also exports `SidebarContent`, the pure nav
                               markup, for isolated testing/reuse.
  SidebarItem.tsx              Single nav link — active state, animated pill,
                                collapsed tooltip, always-present accessible name
  SidebarContext.tsx           SidebarProvider + useSidebar() (collapse + mobile-open state)
  SidebarMobileTrigger.tsx     Hamburger button — put this in your topbar
  nav-config.ts                Nav sections/items config + isNavItemActive(),
                                a pure function pulled out specifically to be
                                unit tested without rendering anything
  index.ts                     Barrel export
  hooks/
    useFocusTrap.ts             Traps Tab focus in a container while active,
                                 sets initial focus, restores focus on close
    useSidebarKeyboardNav.ts    ArrowUp/Down/Home/End roving focus across nav links
    index.ts                    Barrel export
  __tests__/                   Unit tests (see "Testing" below)

components/ui/ThemeToggle.tsx   Animated sun/moon dark-mode switch (used inside the sidebar footer)
lib/theme-provider.tsx          ThemeProvider + useTheme() + no-flash init script
```

`ThemeProvider` and its anti-flash `<script>` are already wired into the
existing root `app/layout.tsx`, so dark mode works everywhere in the app, not
just here.

## Wiring it into a layout (example — not included, since only the sidebar was requested)

```tsx
// app/dashboard/layout.tsx
import { SidebarProvider, Sidebar, SidebarMobileTrigger } from "@/components/dashboard/sidebar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <div className="flex flex-1 flex-col overflow-y-auto">
          <header className="flex h-16 items-center gap-3 border-b border-black/[0.06] px-4 dark:border-white/[0.06] md:hidden">
            <SidebarMobileTrigger />
            <span className="font-display font-bold text-ink dark:text-white">HireAI</span>
          </header>
          <main className="flex-1 p-6">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}
```

## Behavior

- **Desktop (`md:` and up):** fixed rail, 264px expanded / 76px collapsed, spring-animated width. A small round button on the rail's edge toggles collapse; the choice is remembered in `localStorage`.
- **Mobile (below `md:`):** the rail is hidden; `SidebarMobileTrigger` opens an off-canvas drawer with a backdrop. Closes on backdrop click, Escape, close button, or route change. Background scroll is locked while open.
- **Active state:** detected via `isNavItemActive(pathname, href)` — a plain function, not inline JSX logic — using `usePathname()`. The highlighted pill glides between items using a shared `framer-motion` `layoutId` instead of popping.
- **Collapsed rail:** icons only, with a hover/focus tooltip per item. The item's text label is never removed from the DOM, only visually hidden (`sr-only`), so it stays announced by screen readers.
- **Dark/light mode:** toggle lives in the sidebar footer. Persisted in `localStorage`, respects the OS preference on first visit, and applies before paint (no flash).

## Accessibility

- **Landmarks & structure** — the nav is `<nav aria-label="Primary">`; each
  section ("Overview", "Hiring", "Insights") is a `role="group"` labelled by
  its (always-present, only visually hidden when collapsed) heading via
  `aria-labelledby`.
- **Never-empty accessible names** — collapsed nav items and the theme toggle
  keep a real accessible name (via `sr-only` text or `aria-label`) instead of
  relying on a hover-only tooltip. All decorative icons/badges/tooltips are
  `aria-hidden="true"` so they don't get announced twice.
- **Toggle state exposed** — the desktop collapse button has
  `aria-expanded`/`aria-controls`; the mobile trigger has
  `aria-haspopup="dialog"` + `aria-expanded` + `aria-controls`; the theme
  toggle has `aria-pressed`.
- **Keyboard navigation:**
  - Full native Tab order throughout (nothing removed from it).
  - `ArrowUp` / `ArrowDown` / `Home` / `End` roving focus across nav links,
    via `useSidebarKeyboardNav` (opt-in, non-destructive — Tab still works
    exactly as before).
  - `Escape` closes the mobile drawer (already existed in `SidebarContext`).
  - The mobile drawer is a proper modal dialog: opening it moves focus in
    (to the close button), `Tab`/`Shift+Tab` are trapped inside it via
    `useFocusTrap`, and closing it (by any method) restores focus to
    whatever triggered it — all handled generically, with no prop-drilling
    of refs between the trigger and the drawer.
- **Focus states** — the project's global `:focus-visible` outline (see
  `app/globals.css`) covers every interactive element here; nothing in this
  module sets `outline: none` without an equally visible alternative.
- **Reduced motion** — every `framer-motion` transition (rail width, chevron
  rotate, active pill glide, drawer slide/backdrop fade, theme icon
  crossfade) branches through `useReducedMotion()` and drops to an instant
  `duration: 0` when the user has `prefers-reduced-motion: reduce` set.
  (The project's global CSS already zeroes out plain CSS transitions/animations,
  but that doesn't touch framer-motion's own JS-driven animations — this
  closes that gap.)

## Editing the nav

Everything under "Overview / Hiring / Insights" plus the footer "Settings"
link comes from `nav-config.ts` — add, remove, or reorder items there; the
component itself has no hardcoded routes.

## Testing

Components and hooks here are deliberately structured to be testable without
a browser:

- **Pure logic is extracted from JSX.** `isNavItemActive()` is a plain
  function — test it with plain assertions, no rendering required.
- **DOM logic lives in framework-agnostic hooks.** `useFocusTrap` and
  `useSidebarKeyboardNav` only touch the container element they're given, so
  they can be exercised against a small test harness component instead of
  the full `Sidebar`.
- **`SidebarContent` is exported separately from `Sidebar`**, so nav markup
  can be asserted on without also mounting the rail/drawer/motion chrome
  around it.
- **Every interactive element has a stable accessible name/role**, so tests
  can query with Testing Library's `getByRole(..., { name: ... })` instead of
  brittle CSS selectors or test IDs.

Example tests live in `__tests__/` (and `hooks/__tests__/`,
`components/ui/__tests__/`) using [Vitest](https://vitest.dev) +
[Testing Library](https://testing-library.com). This file drop doesn't
include a `package.json`, so to actually run them in your project, add:

```bash
npm install -D vitest @vitejs/plugin-react jsdom \
  @testing-library/react @testing-library/jest-dom @testing-library/user-event
```

...and a script `"test": "vitest"`. `vitest.config.ts` and `vitest.setup.ts`
at the project root are already included and wired to jsdom + the `@/` path
alias used throughout this codebase.
