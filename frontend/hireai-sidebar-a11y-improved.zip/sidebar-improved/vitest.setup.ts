import "@testing-library/jest-dom/vitest";

// framer-motion's useReducedMotion() reads window.matchMedia, which jsdom
// doesn't implement. Stub it so components render instead of throwing.
if (typeof window !== "undefined" && !window.matchMedia) {
  window.matchMedia = (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
  });
}
