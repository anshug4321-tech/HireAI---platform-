# HireAI — Landing Page

A premium marketing landing page for HireAI, built with Next.js (App Router), React, TypeScript, and
Tailwind CSS. UI only — no backend, no real form submission, no auth.

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Structure

```
app/
  layout.tsx          Fonts (Sora / Inter / JetBrains Mono) + metadata
  page.tsx             Assembles all sections
  globals.css          Base styles, .field form input, text-gradient utility

components/
  layout/
    Navbar.tsx          Scroll-aware, blurred nav with mobile menu
    Footer.tsx          Link columns + social icons
  sections/
    Hero.tsx            Headline, CTAs, "spotlight" signature element
    Features.tsx        6-card feature grid
    HowItWorks.tsx       4-step process with connecting line
    Pricing.tsx          3-tier pricing cards
    Testimonials.tsx     Customer quotes
    Faq.tsx              Animated accordion
    Contact.tsx          Contact form (mocked submit) + contact details
  ui/
    Button.tsx           Button + LinkButton (primary / secondary / ghost)
    Card.tsx              Card, Badge, Eyebrow, SectionHeading
    Reveal.tsx            Scroll-triggered fade-up wrapper (Framer Motion)

lib/
  utils.ts              cn() classname helper
```

## Design system

- **Colors** — ink `#12131C` (dark sections & headings), cloud `#F5F6FE` (soft section backgrounds), iris
  blue `#4A5FFF` and violet `#8B5CF6` as the primary gradient pair, mist `#5B6172` for secondary text.
- **Type** — Sora for display headings, Inter for body copy, JetBrains Mono for eyebrows and small labels.
- **Signature motif** — the "spotlight" question sequence in the hero: locked (answered) steps, one glowing
  gradient node for the current step, and a blurred hidden step ahead — a direct visual expression of
  HireAI's core interview rule (one question at a time), reused as connective tissue elsewhere on the page.
- **Motion** — Framer Motion scroll-reveals (`Reveal`) on every section, a scroll-aware navbar, animated FAQ
  accordion, and ambient gradient glows in the hero and contact sections. Respects `prefers-reduced-motion`.

## Not built here

Real form submission, authentication, CMS-driven content, analytics, and any backend integration — this is
UI structure and interaction only.
