"use client";

import { useState, FormEvent } from "react";
import { CheckCircle2, Mail, MapPin, Phone } from "lucide-react";
import { SectionHeading } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";

const details = [
  { icon: Mail, label: "Email us", value: "hello@hireai.example" },
  { icon: Phone, label: "Call us", value: "+1 (415) 555-0182" },
  { icon: MapPin, label: "Visit us", value: "San Francisco, CA" },
];

export function Contact() {
  const [sent, setSent] = useState(false);

  // UI preview only — wire this up to a real endpoint later.
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="contact" className="relative overflow-hidden bg-ink py-24">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -bottom-40 left-1/4 h-[420px] w-[420px] rounded-full bg-iris-500/20 blur-[120px]" />
        <div className="absolute -top-20 right-1/4 h-[380px] w-[380px] rounded-full bg-violet-500/20 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="grid gap-14 lg:grid-cols-2">
          <Reveal>
            <span className="mb-3 inline-block font-mono text-xs uppercase tracking-[0.2em] text-violet-400">
              Contact
            </span>
            <h2 className="font-display text-3xl font-bold leading-tight text-white md:text-4xl">
              Let&apos;s talk about your hiring pipeline
            </h2>
            <p className="mt-4 max-w-md text-base text-white/60">
              Tell us about your interview volume and roles — we&apos;ll show you how HireAI fits into your
              existing process.
            </p>

            <div className="mt-10 space-y-5">
              {details.map((d) => (
                <div key={d.label} className="flex items-center gap-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 text-violet-400">
                    <d.icon size={18} />
                  </div>
                  <div>
                    <p className="text-xs text-white/40">{d.label}</p>
                    <p className="text-sm font-medium text-white">{d.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl">
              {sent ? (
                <div className="flex h-full min-h-[360px] flex-col items-center justify-center text-center">
                  <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-iris-gradient shadow-glow">
                    <CheckCircle2 size={26} className="text-white" />
                  </div>
                  <h3 className="font-display text-xl font-semibold text-white">Message sent</h3>
                  <p className="mt-2 max-w-xs text-sm text-white/60">
                    Thanks for reaching out — someone from our team will follow up within one business day.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="grid gap-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Full name">
                      <input required placeholder="Jordan Lee" className="field" />
                    </Field>
                    <Field label="Work email">
                      <input required type="email" placeholder="jordan@company.com" className="field" />
                    </Field>
                  </div>
                  <Field label="Company">
                    <input placeholder="Your company" className="field" />
                  </Field>
                  <Field label="What are you hiring for?">
                    <textarea rows={4} placeholder="Tell us about your team and volume…" className="field resize-none" />
                  </Field>
                  <Button type="submit" size="lg" className="mt-2 w-full">
                    Send message
                  </Button>
                  <p className="text-center text-xs text-white/40">
                    UI preview — this form isn&apos;t connected to a backend yet.
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5">
      <span className="font-mono text-xs uppercase tracking-wide text-white/40">{label}</span>
      {children}
    </label>
  );
}
