"use client";

import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Sparkles } from "lucide-react";
import { LinkButton } from "@/components/ui/Button";

export function Hero() {
  return (
    <header id="top" className="relative overflow-hidden bg-ink">
      {/* ambient gradient glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 left-1/2 h-[560px] w-[860px] -translate-x-1/2 rounded-full bg-iris-500/30 blur-[120px]" />
        <div className="absolute -top-20 right-0 h-[420px] w-[420px] animate-float rounded-full bg-violet-500/25 blur-[100px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.06)_1px,transparent_0)] bg-[size:32px_32px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 pb-28 pt-20 md:pt-28">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto max-w-3xl text-center"
        >
          <span className="mb-6 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-semibold text-white/80 backdrop-blur">
            <Sparkles size={12} className="text-violet-400" />
            AI interviews, evaluated consistently
          </span>

          <h1 className="font-display text-4xl font-bold leading-[1.08] text-white md:text-6xl">
            Hiring interviews that feel
            <span className="bg-gradient-to-r from-iris-400 to-violet-400 bg-clip-text text-transparent"> fair, fast, </span>
            and finally consistent.
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-base text-white/60 md:text-lg">
            HireAI runs structured, AI-generated interviews with real anti-cheating controls, then hands your HR
            team a scored, ranked shortlist — not a pile of transcripts.
          </p>

          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <LinkButton href="#contact" size="lg">
              Get a demo <ArrowRight size={16} />
            </LinkButton>
            <LinkButton href="#how-it-works" variant="secondary" size="lg" className="!bg-white/5 !text-white !border-white/15 hover:!border-white/30">
              See how it works
            </LinkButton>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-white/40">
            <span className="flex items-center gap-1.5"><CheckCircle2 size={14} /> No credit card required</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 size={14} /> Setup in under a day</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 size={14} /> SOC 2-ready infrastructure</span>
          </div>
        </motion.div>

        {/* signature: spotlight sequence — one question visible, nothing more */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto mt-16 max-w-3xl rounded-3xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl md:p-10"
        >
          <p className="mb-7 font-mono text-xs uppercase tracking-[0.2em] text-white/40">
            What the candidate sees — one question at a time
          </p>
          <div className="flex items-center gap-2 md:gap-3">
            {[1, 2, 3, 4, 5, 6].map((n, i) => (
              <div key={n} className="flex flex-1 items-center gap-2 md:gap-3">
                {n === 3 ? (
                  <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-iris-400 to-violet-500 font-mono text-sm font-semibold text-white shadow-glow">
                    <span className="absolute inset-0 animate-pulse-ring rounded-full" />
                    {n}
                  </div>
                ) : n < 3 ? (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-white/50">
                    <CheckCircle2 size={14} />
                  </div>
                ) : (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/5 font-mono text-xs text-white/30 opacity-60 blur-[1.5px]">
                    ?
                  </div>
                )}
                {i < 5 && <div className="h-px flex-1 bg-white/10" />}
              </div>
            ))}
          </div>
          <p className="mt-5 font-mono text-xs text-white/40 md:text-sm">
            Question 3 of 6 · answered questions locked · upcoming questions hidden
          </p>
        </motion.div>
      </div>
    </header>
  );
}
