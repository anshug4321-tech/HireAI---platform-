"use client";

import { Check } from "lucide-react";
import { SectionHeading } from "@/components/ui/Card";
import { LinkButton } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/lib/utils";

const plans = [
  {
    name: "Starter",
    price: "$0",
    period: "",
    desc: "For trying HireAI out",
    cta: "Start for free",
    items: ["Up to 10 interviews / mo", "1 job role", "Basic AI evaluation", "Email support"],
  },
  {
    name: "Growth",
    price: "$149",
    period: "/mo",
    desc: "For growing hiring teams",
    cta: "Get a demo",
    highlight: true,
    items: [
      "Unlimited interviews",
      "Unlimited job roles",
      "Full AI evaluation & scoring",
      "Proctoring alerts",
      "Priority support",
    ],
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "For global organizations",
    cta: "Talk to sales",
    items: ["SSO & audit logs", "Custom retention policy", "Dedicated success manager", "Custom integrations"],
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Pricing"
          title="Simple pricing that scales with your hiring"
          description="Start free, upgrade when your interview volume grows. No setup fees, cancel anytime."
          align="center"
        />

        <div className="grid gap-6 lg:grid-cols-3">
          {plans.map((p, i) => (
            <Reveal key={p.name} delay={i * 0.08}>
              <div
                className={cn(
                  "relative flex h-full flex-col rounded-3xl border p-8",
                  p.highlight
                    ? "border-transparent bg-ink text-white shadow-glow"
                    : "border-black/[0.08] bg-white"
                )}
              >
                {p.highlight && (
                  <span className="absolute -top-3 left-8 rounded-full bg-gradient-to-r from-iris-400 to-violet-500 px-3 py-1 text-xs font-semibold text-white">
                    Most popular
                  </span>
                )}
                <h3 className={cn("font-display text-xl font-semibold", p.highlight ? "text-white" : "text-ink")}>
                  {p.name}
                </h3>
                <p className={cn("mt-1 text-sm", p.highlight ? "text-white/60" : "text-mist")}>{p.desc}</p>

                <div className="mt-6 flex items-baseline gap-1">
                  <span className="font-display text-4xl font-bold">{p.price}</span>
                  {p.period && (
                    <span className={cn("text-sm", p.highlight ? "text-white/50" : "text-mist")}>{p.period}</span>
                  )}
                </div>

                <ul className="mt-7 flex-1 space-y-3 text-sm">
                  {p.items.map((it) => (
                    <li key={it} className="flex items-center gap-2.5">
                      <span
                        className={cn(
                          "flex h-5 w-5 shrink-0 items-center justify-center rounded-full",
                          p.highlight ? "bg-white/15 text-white" : "bg-iris-50 text-iris-600"
                        )}
                      >
                        <Check size={11} />
                      </span>
                      <span className={p.highlight ? "text-white/85" : "text-ink/80"}>{it}</span>
                    </li>
                  ))}
                </ul>

                <LinkButton
                  href="#contact"
                  variant={p.highlight ? "primary" : "secondary"}
                  className="mt-8 w-full"
                >
                  {p.cta}
                </LinkButton>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
