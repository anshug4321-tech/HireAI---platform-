import { Star } from "lucide-react";
import { SectionHeading, Card } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";

const testimonials = [
  {
    quote: "We cut first-round screening time by 70% without losing signal. Our recruiters finally spend their time on real conversations.",
    author: "Elena Marsh",
    role: "VP Talent, Northbeam Fintech",
    color: "from-iris-400 to-violet-500",
  },
  {
    quote: "Candidates actually say the process feels fair. That alone changed how people talk about us as an employer.",
    author: "Raj Patel",
    role: "Head of People, Loomstack",
    color: "from-violet-400 to-iris-500",
  },
  {
    quote: "The evaluation breakdown gives us something concrete to point to in debriefs instead of arguing over gut feel.",
    author: "Camille Dubois",
    role: "Recruiting Lead, Ferra Logistics",
    color: "from-iris-500 to-violet-400",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="bg-cloud py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading eyebrow="Customers" title="Trusted by hiring teams that move fast" align="center" />
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.author} delay={i * 0.08}>
              <Card className="flex h-full flex-col">
                <div className="mb-4 flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star key={j} size={14} className="fill-violet-500 text-violet-500" />
                  ))}
                </div>
                <p className="flex-1 text-sm leading-relaxed text-ink/80">&ldquo;{t.quote}&rdquo;</p>
                <div className="mt-6 flex items-center gap-3">
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br ${t.color} text-xs font-semibold text-white`}
                  >
                    {t.author.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-ink">{t.author}</p>
                    <p className="text-xs text-mist">{t.role}</p>
                  </div>
                </div>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
