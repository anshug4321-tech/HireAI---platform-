"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { SectionHeading } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/lib/utils";

const faqs = [
  {
    q: "Does HireAI replace human recruiters?",
    a: "No — it handles the first-round screening consistently and surfaces a structured evaluation, so your recruiters spend their time on the candidates worth a real conversation.",
  },
  {
    q: "Can candidates see the questions in advance?",
    a: "Never. Questions are drawn from your approved bank at interview time and shown one at a time, with no way to preview, skip back, or export the list.",
  },
  {
    q: "What happens if a candidate loses connection?",
    a: "Answers are saved after every question, so a dropped connection doesn't cost the candidate their progress.",
  },
  {
    q: "Is candidate data secure?",
    a: "Yes — role-based access, encryption at rest, and full audit logs mean only your HR team ever sees evaluation data.",
  },
  {
    q: "Can we bring our own interview questions?",
    a: "Yes. AI-generated questions are a starting point — HR can edit, delete, add, and set difficulty or time limits before anything goes live.",
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="bg-white py-24">
      <div className="mx-auto max-w-3xl px-6">
        <SectionHeading eyebrow="FAQ" title="Questions, answered" align="center" />
        <div className="space-y-3">
          {faqs.map((f, i) => (
            <Reveal key={f.q} delay={i * 0.05}>
              <div
                className={cn(
                  "overflow-hidden rounded-2xl border transition-colors",
                  open === i ? "border-iris-400/40 bg-iris-50/40" : "border-black/[0.08]"
                )}
              >
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  className="flex w-full items-center justify-between px-6 py-5 text-left"
                >
                  <span className="font-medium text-ink">{f.q}</span>
                  <span
                    className={cn(
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-iris-gradient-soft text-iris-600 transition-transform duration-300",
                      open === i && "rotate-45"
                    )}
                  >
                    <Plus size={14} />
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {open === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <p className="px-6 pb-5 text-sm leading-relaxed text-mist">{f.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
