import { BarChart3, Eye, ShieldCheck, Sparkles, Timer, Users } from "lucide-react";
import { SectionHeading, Card } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";

const features = [
  {
    icon: Sparkles,
    title: "AI question generation",
    body: "Give it a role and key skills, get a ready-to-use bank of technical, HR, and scenario questions in seconds.",
  },
  {
    icon: Eye,
    title: "One question at a time",
    body: "Candidates never see what's coming or go back — every interview stays fair, timed, and comparable.",
  },
  {
    icon: ShieldCheck,
    title: "Built-in proctoring",
    body: "Tab-switch detection, copy/paste blocking, and full activity logs — no extra software to install.",
  },
  {
    icon: BarChart3,
    title: "Structured evaluation",
    body: "Every answer is scored on technical depth, communication, and role match — the same way, every time.",
  },
  {
    icon: Users,
    title: "Built for high volume",
    body: "Run dozens of interviews in parallel across roles and locations without losing consistency.",
  },
  {
    icon: Timer,
    title: "Faster time-to-decision",
    body: "A ranked, evaluated shortlist lands in your dashboard minutes after the last interview ends.",
  },
];

export function Features() {
  return (
    <section id="features" className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Features"
          title="Everything you need to run interviews at scale"
          description="From question generation to final decision, HireAI keeps every step structured, secure, and easy to audit."
          align="center"
        />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.06}>
              <Card className="group h-full transition-all duration-300 hover:-translate-y-1 hover:shadow-glow">
                <div className="mb-5 flex h-11 w-11 items-center justify-center rounded-xl bg-iris-gradient-soft text-iris-600 transition-colors group-hover:bg-iris-gradient group-hover:text-white">
                  <f.icon size={20} />
                </div>
                <h3 className="font-display text-lg font-semibold text-ink">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-mist">{f.body}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
