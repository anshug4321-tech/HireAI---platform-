import { FileEdit, MessageSquareText, ScanSearch, Trophy } from "lucide-react";
import { SectionHeading } from "@/components/ui/Card";
import { Reveal } from "@/components/ui/Reveal";

const steps = [
  {
    icon: FileEdit,
    title: "Define the role",
    body: "Enter a job title and key skills. HireAI generates a full question bank — technical, HR, scenario, and communication.",
  },
  {
    icon: MessageSquareText,
    title: "Candidate interviews",
    body: "Each candidate gets a randomized set from your approved bank, one question at a time, with a timer and no way back.",
  },
  {
    icon: ScanSearch,
    title: "AI evaluates the answers",
    body: "Every response is scored for technical depth, communication, and role match, with strengths and gaps called out.",
  },
  {
    icon: Trophy,
    title: "HR reviews and decides",
    body: "Your team gets a ranked shortlist with full transcripts — select, hold, or reject with one click.",
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-cloud py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="How it works"
          title="From job title to shortlist in four steps"
          description="No manual scheduling juggling, no inconsistent scoring between interviewers — just a repeatable pipeline."
          align="center"
        />

        <div className="relative grid gap-10 md:grid-cols-4 md:gap-6">
          {/* connecting line, desktop only */}
          <div className="absolute left-0 right-0 top-7 hidden h-px bg-gradient-to-r from-iris-400/0 via-iris-400/40 to-violet-500/0 md:block" />

          {steps.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.08} className="relative">
              <div className="relative z-10 flex items-center gap-3 md:flex-col md:items-start md:gap-0">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white shadow-card">
                  <s.icon size={22} className="text-iris-600" />
                </div>
                <span className="font-mono text-xs font-semibold text-violet-500 md:mt-4">
                  STEP {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold text-ink">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-mist">{s.body}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
