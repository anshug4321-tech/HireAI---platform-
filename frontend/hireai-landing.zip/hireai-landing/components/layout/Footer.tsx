import Link from "next/link";
import { Github, Linkedin, Twitter } from "lucide-react";

const columns = [
  {
    title: "Product",
    links: ["Features", "How it works", "Pricing", "Security"],
  },
  {
    title: "Company",
    links: ["About", "Careers", "Blog", "Contact"],
  },
  {
    title: "Resources",
    links: ["Documentation", "API reference", "Support", "Status"],
  },
  {
    title: "Legal",
    links: ["Privacy", "Terms", "Data processing"],
  },
];

export function Footer() {
  return (
    <footer className="bg-ink pt-20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 pb-14 md:grid-cols-[1.4fr_2fr]">
          <div>
            <Link href="#top" className="flex items-center gap-2.5 font-display text-lg font-bold text-white">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-iris-gradient text-sm font-bold text-white">
                H
              </span>
              HireAI
            </Link>
            <p className="mt-4 max-w-xs text-sm text-white/50">
              Structured, AI-evaluated interviews for hiring teams that need to move fast without losing
              consistency.
            </p>
            <div className="mt-6 flex gap-3">
              {[Twitter, Linkedin, Github].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-white/50 transition-colors hover:border-white/25 hover:text-white"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {columns.map((col) => (
              <div key={col.title}>
                <p className="mb-4 text-sm font-semibold text-white">{col.title}</p>
                <ul className="space-y-3">
                  {col.links.map((l) => (
                    <li key={l}>
                      <a href="#" className="text-sm text-white/50 transition-colors hover:text-white">
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/10 py-8 text-xs text-white/40 sm:flex-row">
          <p>© 2026 HireAI. All rights reserved.</p>
          <p>Built for hiring teams that value consistency.</p>
        </div>
      </div>
    </footer>
  );
}
