# HireAI — HR Authentication Module

Login, Forgot Password, Reset Password, and the post-login Dashboard entry page for HireAI's HR/Admin
console. Built with Next.js (App Router), TypeScript, and Tailwind CSS. **UI only** — form validation is
real, but nothing calls a server. Every spot meant for a backend call is marked `UI preview`.

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000 — it redirects to `/login`.

- `/login` — sign in
- `/forgot-password` — request a reset link
- `/reset-password?token=abc123` — set a new password (omit `?token=` to see the invalid/expired state)
- `/dashboard` — entry screen shown right after sign-in

## Structure

```
app/
  layout.tsx                 Fonts + metadata
  page.tsx                   Redirects to /login
  login/page.tsx
  forgot-password/page.tsx
  reset-password/page.tsx    Reads ?token= via useSearchParams (Suspense-wrapped)
  dashboard/page.tsx

components/
  auth/
    AuthLayout.tsx            Shared split-screen shell (branding panel + form panel)
    LoginForm.tsx             Email/password, remember me, validation, simulated sign-in
    ForgotPasswordForm.tsx    Email → simulated "check your inbox" state
    ResetPasswordForm.tsx     New password + confirm, strength meter, invalid-token state
  dashboard/
    Topbar.tsx                 Logo, notifications, account menu
    StatCard.tsx                Small metric card
  ui/
    Button.tsx                  Primary/secondary/ghost, built-in loading spinner
    FormField.tsx                FieldWrapper (label + error/hint) + TextInput
    PasswordInput.tsx            Password field with show/hide toggle
    PasswordStrengthMeter.tsx    Strength bar + live requirement checklist
    Alert.tsx                    Inline error/success/info banner

lib/
  utils.ts                    cn() classname helper
  validation.ts                Client-side email/password validators (UI feedback only)
```

## What's real vs. mocked

**Real (client-side):**
- Email format and required-field validation
- Password strength scoring and requirement checklist
- Password confirmation matching
- Show/hide password toggles
- Loading states, disabled states, focus states
- Reset-password token presence check (drives the invalid/expired UI state)

**Mocked (`UI preview` comments mark these):**
- Actual authentication — login always "succeeds" after client validation and redirects to `/dashboard`
- "Send reset link" — always shows the success state after a simulated delay
- "Reset password" — always shows the success state after a simulated delay
- Dashboard stats and quick actions — static placeholder data, no real candidate/role data

## Design system

Matches the rest of the HireAI product: ink `#12131C`, cloud `#F5F6FE`, iris blue `#4A5FFF` → violet
`#8B5CF6` gradient, Sora display type, Inter body, JetBrains Mono for small labels. The auth branding panel
reuses the product's core promise ("one question at a time") as supporting copy rather than introducing a
new visual language.

## Next steps (not built here)

- Real authentication (session/JWT, SSO if needed), rate limiting on login attempts
- Real password reset token issuance, validation, and expiry server-side
- Route protection / middleware so `/dashboard` requires a valid session
- Account lockout, 2FA, audit logging of sign-ins
