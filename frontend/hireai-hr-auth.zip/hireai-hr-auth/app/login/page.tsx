import { AuthLayout } from "@/components/auth/AuthLayout";
import { LoginForm } from "@/components/auth/LoginForm";

export default function LoginPage() {
  return (
    <AuthLayout
      eyebrow="HR & Admin"
      title="Sign in to your account"
      subtitle="Enter your work credentials to access the HireAI console."
      footer={
        <p className="text-center text-sm text-mist">
          Don&apos;t have an account?{" "}
          <a href="#" className="font-medium text-iris-600 hover:text-iris-500">
            Contact your workspace admin
          </a>
        </p>
      }
    >
      <LoginForm />
    </AuthLayout>
  );
}
