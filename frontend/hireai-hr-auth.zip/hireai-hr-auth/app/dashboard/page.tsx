import { ArrowRight, FileText, Sparkles, Users, BarChart3 } from "lucide-react";
import { Topbar } from "@/components/dashboard/Topbar";
import { StatCard } from "@/components/dashboard/StatCard";

const quickActions = [
  {
    icon: Users,
    title: "Review candidates",
    body: "See who's applied, in progress, or ready for a decision.",
  },
  {
    icon: Sparkles,
    title: "Generate interview questions",
    body: "Give AI a role and skills to build a fresh question bank.",
  },
  {
    icon: FileText,
    title: "Open a job role",
    body: "Create or edit a role candidates can interview for.",
  },
  {
    icon: BarChart3,
    title: "View analytics",
    body: "Track score trends and hiring funnel health.",
  },
];

export default function DashboardEntryPage() {
  return (
    <div className="min-h-screen bg-cloud">
      <Topbar />

      <main className="mx-auto max-w-7xl px-6 py-10">
        <div className="mb-8">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-iris-500">Welcome back</p>
          <h1 className="mt-2 font-display text-3xl font-bold text-ink">Good to see you, Riya</h1>
          <p className="mt-1 text-sm text-mist">Here's what's happening across your hiring pipeline today.</p>
        </div>

        <div className="mb-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard icon={Users} label="Active candidates" value="24" trend="+6 today" />
          <StatCard icon={Sparkles} label="Interviewing now" value="3" />
          <StatCard icon={FileText} label="Open job roles" value="5" />
          <StatCard icon={BarChart3} label="Avg. match score" value="79%" trend="+4%" />
        </div>

        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-ink">Quick actions</h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((a) => (
            <button
              key={a.title}
              className="group flex h-full flex-col items-start rounded-2xl border border-black/[0.06] bg-white p-5 text-left shadow-card transition-all duration-200 hover:-translate-y-1 hover:shadow-glow"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-iris-gradient-soft text-iris-600 transition-colors group-hover:bg-iris-gradient group-hover:text-white">
                <a.icon size={18} />
              </span>
              <p className="mt-4 font-display text-sm font-semibold text-ink">{a.title}</p>
              <p className="mt-1.5 flex-1 text-xs leading-relaxed text-mist">{a.body}</p>
              <span className="mt-4 flex items-center gap-1 text-xs font-medium text-iris-600">
                Open <ArrowRight size={12} className="transition-transform group-hover:translate-x-0.5" />
              </span>
            </button>
          ))}
        </div>

        <div className="mt-10 rounded-2xl border border-dashed border-black/12 bg-white/60 p-6 text-center text-sm text-mist">
          This is the entry point into the HR dashboard — candidate lists, question banks, and analytics live
          in their own module. This page is UI-only and not yet wired to real data.
        </div>
      </main>
    </div>
  );
}
