"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { FieldWrapper, TextInput } from "@/components/ui/FormField";
import { PasswordInput } from "@/components/ui/PasswordInput";
import { Alert } from "@/components/ui/Alert";
import { isValidEmail } from "@/lib/validation";

interface Errors {
  email?: string;
  password?: string;
}

export function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState<Errors>({});
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState("");

  const validate = () => {
    const next: Errors = {};
    if (!email.trim()) next.email = "Enter your work email.";
    else if (!isValidEmail(email)) next.email = "Enter a valid email address.";
    if (!password) next.password = "Enter your password.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setFormError("");
    if (!validate()) return;

    // UI preview — replace with a real authentication call.
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      router.push("/dashboard");
    }, 900);
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="grid gap-5">
      {formError && <Alert tone="error">{formError}</Alert>}

      <FieldWrapper label="Work email" htmlFor="email" error={errors.email}>
        <TextInput
          id="email"
          type="email"
          autoComplete="email"
          placeholder="you@company.com"
          value={email}
          error={!!errors.email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </FieldWrapper>

      <FieldWrapper
        label="Password"
        htmlFor="password"
        error={errors.password}
        action={
          <Link href="/forgot-password" className="text-xs font-medium text-iris-600 hover:text-iris-500">
            Forgot password?
          </Link>
        }
      >
        <PasswordInput
          id="password"
          autoComplete="current-password"
          placeholder="••••••••"
          value={password}
          error={!!errors.password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </FieldWrapper>

      <label className="flex items-center gap-2.5 text-sm text-mist">
        <input
          type="checkbox"
          checked={remember}
          onChange={(e) => setRemember(e.target.checked)}
          className="h-4 w-4 rounded border-black/20 text-iris-500 focus:ring-iris-400"
        />
        Keep me signed in for 30 days
      </label>

      <Button type="submit" size="lg" loading={loading}>
        {loading ? "Signing in…" : "Sign in"}
      </Button>

      <p className="text-center text-xs text-mist">
        UI preview — authentication isn&apos;t wired up yet. Any valid email/password signs you in.
      </p>
    </form>
  );
}
