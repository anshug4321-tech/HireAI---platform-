"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, MailCheck } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { FieldWrapper, TextInput } from "@/components/ui/FormField";
import { isValidEmail } from "@/lib/validation";

export function ForgotPasswordForm() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return setError("Enter your work email.");
    if (!isValidEmail(email)) return setError("Enter a valid email address.");
    setError("");

    // UI preview — replace with a real "send reset link" call.
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
    }, 900);
  };

  if (sent) {
    return (
      <div className="grid gap-5">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-iris-gradient-soft text-iris-600">
          <MailCheck size={22} />
        </div>
        <div>
          <p className="font-display text-lg font-semibold text-ink">Check your inbox</p>
          <p className="mt-1.5 text-sm text-mist">
            If an account exists for <span className="font-medium text-ink">{email}</span>, a password reset
            link is on its way.
          </p>
        </div>
        <ul className="space-y-2 text-sm text-mist">
          <li className="flex items-center gap-2"><CheckCircle2 size={14} className="text-success-500" /> The link expires in 30 minutes</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={14} className="text-success-500" /> Check spam if it doesn&apos;t arrive shortly</li>
        </ul>
        <Button variant="secondary" onClick={() => setSent(false)}>
          Use a different email
        </Button>
        <Link href="/login" className="flex items-center justify-center gap-1.5 text-sm font-medium text-iris-600 hover:text-iris-500">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="grid gap-5">
      <FieldWrapper label="Work email" htmlFor="email" error={error} hint="We'll send a secure link to reset your password.">
        <TextInput
          id="email"
          type="email"
          autoComplete="email"
          placeholder="you@company.com"
          value={email}
          error={!!error}
          onChange={(e) => setEmail(e.target.value)}
        />
      </FieldWrapper>

      <Button type="submit" size="lg" loading={loading}>
        {loading ? "Sending link…" : "Send reset link"}
      </Button>

      <Link href="/login" className="flex items-center justify-center gap-1.5 text-sm font-medium text-mist hover:text-ink">
        <ArrowLeft size={14} /> Back to sign in
      </Link>
    </form>
  );
}
