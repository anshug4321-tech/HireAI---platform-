"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { FieldWrapper } from "@/components/ui/FormField";
import { PasswordInput } from "@/components/ui/PasswordInput";
import { PasswordStrengthMeter } from "@/components/ui/PasswordStrengthMeter";
import { Alert } from "@/components/ui/Alert";
import { getPasswordStrength } from "@/lib/validation";

export function ResetPasswordForm({ token }: { token: string | null }) {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<{ password?: string; confirm?: string }>({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  // UI preview — in production, absence/expiry of a valid token comes from the server.
  if (!token) {
    return (
      <div className="grid gap-5">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-danger-50 text-danger-500">
          <ShieldAlert size={22} />
        </div>
        <div>
          <p className="font-display text-lg font-semibold text-ink">This link is invalid or expired</p>
          <p className="mt-1.5 text-sm text-mist">
            Password reset links expire after 30 minutes. Request a new one to continue.
          </p>
        </div>
        <Link href="/forgot-password">
          <Button className="w-full">Request a new link</Button>
        </Link>
      </div>
    );
  }

  if (done) {
    return (
      <div className="grid gap-5">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success-50 text-success-500">
          <CheckCircle2 size={22} />
        </div>
        <div>
          <p className="font-display text-lg font-semibold text-ink">Password updated</p>
          <p className="mt-1.5 text-sm text-mist">Your password has been reset. You can now sign in.</p>
        </div>
        <Button onClick={() => router.push("/login")}>Continue to sign in</Button>
      </div>
    );
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const next: typeof errors = {};
    if (getPasswordStrength(password) === "empty") next.password = "Enter a new password.";
    else if (getPasswordStrength(password) === "weak") next.password = "Choose a stronger password.";
    if (confirm !== password) next.confirm = "Passwords don't match.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    // UI preview — replace with a real "set new password" call.
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setDone(true);
    }, 900);
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="grid gap-5">
      <FieldWrapper label="New password" htmlFor="password" error={errors.password}>
        <PasswordInput
          id="password"
          autoComplete="new-password"
          placeholder="••••••••"
          value={password}
          error={!!errors.password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <PasswordStrengthMeter value={password} />
      </FieldWrapper>

      <FieldWrapper label="Confirm new password" htmlFor="confirm" error={errors.confirm}>
        <PasswordInput
          id="confirm"
          autoComplete="new-password"
          placeholder="••••••••"
          value={confirm}
          error={!!errors.confirm}
          onChange={(e) => setConfirm(e.target.value)}
        />
      </FieldWrapper>

      {errors.confirm === undefined && confirm.length > 0 && confirm === password && (
        <Alert tone="success">Passwords match.</Alert>
      )}

      <Button type="submit" size="lg" loading={loading}>
        {loading ? "Updating password…" : "Reset password"}
      </Button>
    </form>
  );
}
