import Link from "next/link";
import { CheckCircle2, ShieldCheck, Sparkles } from "lucide-react";

const highlights = [
  "One question at a time — fair, comparable interviews",
  "AI-scored evaluations the moment interviews finish",
  "Role-based access, full audit trail, SOC 2-ready",
];

export function AuthLayout({
  eyebrow,
  title,
  subtitle,
  children,
  footer,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* branding panel */}
      <div className="relative hidden overflow-hidden bg-ink lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -top-32 left-1/3 h-[480px] w-[480px] rounded-full bg-iris-500/25 blur-[120px]" />
          <div className="absolute bottom-0 right-0 h-[380px] w-[380px] animate-float rounded-full bg-violet-500/20 blur-[110px]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.05)_1px,transparent_0)] bg-[size:32px_32px]" />
        </div>

        <div className="relative px-12 pt-12">
          <Link href="/login" className="flex items-center gap-2.5 font-display text-lg font-bold text-white">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-iris-gradient text-sm font-bold text-white shadow-glow">
              H
            </span>
            HireAI
          </Link>
        </div>

        <div className="relative px-12">
          <span className="mb-5 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-semibold text-white/80">
            <Sparkles size={12} className="text-violet-400" /> HR & Admin console
          </span>
          <h2 className="max-w-md font-display text-3xl font-bold leading-tight text-white">
            Run interviews that stay fair, fast, and consistent.
          </h2>
          <ul className="mt-8 space-y-3.5">
            {highlights.map((h) => (
              <li key={h} className="flex items-start gap-2.5 text-sm text-white/60">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-iris-400" />
                {h}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative flex items-center gap-2.5 border-t border-white/10 px-12 py-7 text-xs text-white/40">
          <ShieldCheck size={14} /> Encrypted at rest · Role-based access · Full audit logs
        </div>
      </div>

      {/* form panel */}
      <div className="flex items-center justify-center bg-white px-6 py-16">
        <div className="w-full max-w-sm animate-fade-up">
          <Link href="/login" className="mb-10 flex items-center gap-2.5 font-display text-lg font-bold text-ink lg:hidden">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-iris-gradient text-sm font-bold text-white">
              H
            </span>
            HireAI
          </Link>

          <p className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-iris-500">{eyebrow}</p>
          <h1 className="font-display text-2xl font-bold text-ink">{title}</h1>
          <p className="mt-2 text-sm text-mist">{subtitle}</p>

          <div className="mt-8">{children}</div>

          {footer && <div className="mt-8">{footer}</div>}
        </div>
      </div>
    </div>
  );
}
