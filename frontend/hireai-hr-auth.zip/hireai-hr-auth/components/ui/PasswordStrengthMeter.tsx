import { Check, X } from "lucide-react";
import { getPasswordStrength, passwordRules } from "@/lib/validation";
import { cn } from "@/lib/utils";

const meta: Record<ReturnType<typeof getPasswordStrength>, { label: string; color: string; width: string }> = {
  empty: { label: "", color: "bg-black/10", width: "w-0" },
  weak: { label: "Weak", color: "bg-danger-500", width: "w-1/3" },
  fair: { label: "Fair", color: "bg-iris-500", width: "w-2/3" },
  strong: { label: "Strong", color: "bg-success-500", width: "w-full" },
};

export function PasswordStrengthMeter({ value, dark }: { value: string; dark?: boolean }) {
  const strength = getPasswordStrength(value);
  const m = meta[strength];

  return (
    <div className="mt-1">
      {value.length > 0 && (
        <div className="mb-3 flex items-center gap-2">
          <div className={cn("h-1.5 flex-1 overflow-hidden rounded-full", dark ? "bg-white/10" : "bg-black/8")}>
            <div className={cn("h-full rounded-full transition-all duration-300", m.color, m.width)} />
          </div>
          <span className={cn("w-10 text-xs font-medium", dark ? "text-white/50" : "text-mist")}>{m.label}</span>
        </div>
      )}
      <ul className="grid grid-cols-2 gap-1.5">
        {passwordRules.map((rule) => {
          const passed = rule.test(value);
          return (
            <li
              key={rule.id}
              className={cn(
                "flex items-center gap-1.5 text-xs",
                passed ? "text-success-500" : dark ? "text-white/35" : "text-mist/70"
              )}
            >
              {passed ? <Check size={12} /> : <X size={12} className="opacity-50" />}
              {rule.label}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
