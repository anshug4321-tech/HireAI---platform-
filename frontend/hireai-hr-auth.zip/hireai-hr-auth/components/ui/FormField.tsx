import { InputHTMLAttributes, forwardRef } from "react";
import { AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface FieldWrapperProps {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  action?: React.ReactNode;
  dark?: boolean;
  children: React.ReactNode;
}

export function FieldWrapper({ label, htmlFor, error, hint, action, dark, children }: FieldWrapperProps) {
  return (
    <div className="grid gap-1.5">
      <div className="flex items-center justify-between">
        <label
          htmlFor={htmlFor}
          className={cn("font-mono text-xs uppercase tracking-wide", dark ? "text-white/50" : "text-mist")}
        >
          {label}
        </label>
        {action}
      </div>
      {children}
      {error ? (
        <p className="flex items-center gap-1.5 text-xs font-medium text-danger-500">
          <AlertCircle size={12} /> {error}
        </p>
      ) : (
        hint && <p className={cn("text-xs", dark ? "text-white/40" : "text-mist/80")}>{hint}</p>
      )}
    </div>
  );
}

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
  dark?: boolean;
}

export const TextInput = forwardRef<HTMLInputElement, InputProps>(function TextInput(
  { error, dark, className, ...props },
  ref
) {
  return (
    <input
      ref={ref}
      className={cn(
        dark ? "field-dark" : "field",
        error && (dark ? "!border-danger-500/70" : "!border-danger-500"),
        className
      )}
      {...props}
    />
  );
});
