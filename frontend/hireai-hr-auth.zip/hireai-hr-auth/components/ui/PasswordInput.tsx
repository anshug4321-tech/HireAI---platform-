"use client";

import { useState, forwardRef } from "react";
import { Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
  dark?: boolean;
}

export const PasswordInput = forwardRef<HTMLInputElement, Props>(function PasswordInput(
  { error, dark, className, ...props },
  ref
) {
  const [visible, setVisible] = useState(false);

  return (
    <div className="relative">
      <input
        ref={ref}
        type={visible ? "text" : "password"}
        className={cn(
          dark ? "field-dark" : "field",
          "pr-11",
          error && (dark ? "!border-danger-500/70" : "!border-danger-500"),
          className
        )}
        {...props}
      />
      <button
        type="button"
        tabIndex={-1}
        onClick={() => setVisible((v) => !v)}
        className={cn(
          "absolute right-3 top-1/2 -translate-y-1/2 transition-colors",
          dark ? "text-white/40 hover:text-white/70" : "text-mist hover:text-ink"
        )}
        aria-label={visible ? "Hide password" : "Show password"}
      >
        {visible ? <EyeOff size={16} /> : <Eye size={16} />}
      </button>
    </div>
  );
});
