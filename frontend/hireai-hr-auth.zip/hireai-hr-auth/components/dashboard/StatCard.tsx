import { LucideIcon } from "lucide-react";

export function StatCard({
  icon: Icon,
  label,
  value,
  trend,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  trend?: string;
}) {
  return (
    <div className="rounded-2xl border border-black/[0.06] bg-white p-5 shadow-card">
      <div className="flex items-center justify-between">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-iris-gradient-soft text-iris-600">
          <Icon size={18} />
        </span>
        {trend && <span className="text-xs font-semibold text-success-500">{trend}</span>}
      </div>
      <p className="mt-4 font-display text-2xl font-bold text-ink">{value}</p>
      <p className="mt-1 text-xs text-mist">{label}</p>
    </div>
  );
}
