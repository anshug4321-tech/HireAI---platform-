"use client";

import Link from "next/link";
import { useState } from "react";
import { Bell, ChevronDown, LogOut, Settings, User } from "lucide-react";

export function Topbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-black/[0.06] bg-white/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link href="/dashboard" className="flex items-center gap-2.5 font-display text-lg font-bold text-ink">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-iris-gradient text-sm font-bold text-white">
            H
          </span>
          HireAI
        </Link>

        <div className="flex items-center gap-3">
          <button
            className="relative flex h-9 w-9 items-center justify-center rounded-lg text-mist hover:bg-cloud hover:text-ink"
            aria-label="Notifications"
          >
            <Bell size={18} />
            <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-violet-500" />
          </button>

          <div className="relative">
            <button
              onClick={() => setMenuOpen((o) => !o)}
              className="flex items-center gap-2 rounded-lg py-1.5 pl-1.5 pr-2.5 hover:bg-cloud"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-iris-gradient-soft text-sm font-semibold text-iris-600">
                RN
              </span>
              <span className="hidden text-sm font-medium text-ink sm:block">Riya Nair</span>
              <ChevronDown size={14} className="text-mist" />
            </button>

            {menuOpen && (
              <div className="absolute right-0 mt-2 w-48 rounded-xl border border-black/[0.08] bg-white p-1.5 shadow-card">
                <button className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-ink hover:bg-cloud">
                  <User size={15} /> Profile
                </button>
                <button className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-ink hover:bg-cloud">
                  <Settings size={15} /> Settings
                </button>
                <div className="my-1 h-px bg-black/[0.06]" />
                <Link
                  href="/login"
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-danger-500 hover:bg-danger-50"
                >
                  <LogOut size={15} /> Sign out
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
