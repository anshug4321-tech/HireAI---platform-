export function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export type PasswordStrength = "empty" | "weak" | "fair" | "strong";

export function getPasswordStrength(value: string): PasswordStrength {
  if (!value) return "empty";
  let score = 0;
  if (value.length >= 8) score++;
  if (value.length >= 12) score++;
  if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score++;
  if (/\d/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;

  if (score <= 1) return "weak";
  if (score <= 3) return "fair";
  return "strong";
}

export const passwordRules = [
  { id: "length", label: "At least 8 characters", test: (v: string) => v.length >= 8 },
  { id: "case", label: "Upper & lowercase letters", test: (v: string) => /[A-Z]/.test(v) && /[a-z]/.test(v) },
  { id: "number", label: "At least one number", test: (v: string) => /\d/.test(v) },
  { id: "symbol", label: "At least one symbol", test: (v: string) => /[^A-Za-z0-9]/.test(v) },
];
