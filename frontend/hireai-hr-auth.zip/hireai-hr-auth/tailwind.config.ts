import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#12131C",
        mist: "#5B6172",
        cloud: "#F5F6FE",
        line: "#00000012",
        success: {
          50: "#EAF7F1",
          500: "#3D9670",
        },
        danger: {
          50: "#FBEAE7",
          500: "#D1543F",
        },
        iris: {
          50: "#EEF1FF",
          100: "#DFE4FF",
          400: "#6C7CFF",
          500: "#4A5FFF",
          600: "#3646E0",
        },
        violet: {
          400: "#A78BFA",
          500: "#8B5CF6",
          600: "#7C3AED",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "iris-gradient": "linear-gradient(135deg, #4A5FFF 0%, #8B5CF6 100%)",
        "iris-gradient-soft": "linear-gradient(135deg, #EEF1FF 0%, #F3EEFF 100%)",
      },
      boxShadow: {
        glow: "0 20px 60px -15px rgba(90,92,255,0.35)",
        card: "0 1px 2px rgba(18,19,28,0.04), 0 12px 28px -12px rgba(18,19,28,0.08)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "spin-slow": {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.6s ease both",
        float: "float 6s ease-in-out infinite",
        "spin-slow": "spin-slow 1s linear infinite",
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.5rem",
        "3xl": "2rem",
      },
    },
  },
  plugins: [],
};
export default config;
